<?php
/** GET /api/helpers.php?q=&service=&sort=rating|name|city&page=1  ->  verified helpers as JSON (powers live search on helpers.php). */
require __DIR__ . '/../includes/bootstrap.php';
api_method('GET'); api_guard('helpers', 180, 60);
$services = zam_load_services($pdo);
$sort = in_array($_GET['sort'] ?? '', ['rating', 'name', 'city'], true) ? $_GET['sort'] : 'rating';
$service = isset($services[$_GET['service'] ?? '']) ? $_GET['service'] : '';
$r = zam_list_helpers($pdo, substr((string)($_GET['q'] ?? ''), 0, 80), $service, $sort, max(1, (int)($_GET['page'] ?? 1)));
$items = array_map(fn($h) => [
  'id' => (int)$h['id'], 'name' => $h['name'], 'city' => $h['city'], 'services' => $h['service_names'] ? explode(', ', $h['service_names']) : [],
  'rating' => (float)$h['rating'], 'review_count' => (int)$h['review_count'], 'photo' => zam_photo_url($h['photo_path']),
  'verified' => (bool)$h['is_verified'], 'busy_now' => (bool)$h['busy_now'],
  'book_url' => 'book.php?helper=' . (int)$h['id'], 'profile_url' => 'helper-view.php?id=' . (int)$h['id'],
], $r['items']);
api_json(['total' => $r['total'], 'all_count' => $r['all_count'], 'page' => $r['page'], 'pages' => $r['pages'], 'items' => $items]);
