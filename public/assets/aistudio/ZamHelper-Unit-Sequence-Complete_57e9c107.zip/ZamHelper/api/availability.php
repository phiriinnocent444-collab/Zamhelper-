<?php
/** GET /api/availability.php?helper=4&service=cleaning&when=2026-11-02T10:00&duration=120  (omit "when" for as-soon-as-possible) */
require __DIR__ . '/../includes/bootstrap.php';
api_method('GET'); api_guard('availability', 120, 60);
if (!$pdo) api_json(['error' => 'database_unavailable'], 503);
$helperId = (int)(filter_var($_GET['helper'] ?? null, FILTER_VALIDATE_INT) ?: 0); $service = (string)($_GET['service'] ?? '');
$duration = (int)($_GET['duration'] ?? ZAM_DEFAULT_DURATION); if (!zam_valid_duration($duration)) $duration = ZAM_DEFAULT_DURATION;
if (!$helperId) api_json(['error' => 'helper_required'], 400);
$q = $pdo->prepare("SELECT h.id,h.name FROM helpers h JOIN helper_services hs ON hs.helper_id=h.id JOIN services s ON s.id=hs.service_id
                    WHERE h.id=? AND h.is_active=1 AND h.is_verified=1 AND h.is_available=1 AND s.service_key=? LIMIT 1");
$q->execute([$helperId, $service]); $h = $q->fetch();
if (!$h) api_json(['available' => false, 'reason' => 'not_offered', 'message' => 'This helper is not available for this service.']);
$when = trim((string)($_GET['when'] ?? ''));
if ($when === '') { $start = zam_now(); } else {
  $start = zam_parse_slot($when); if (!$start) api_json(['error' => 'bad_time'], 400);
  if ($errs = zam_slot_errors($start)) api_json(['available' => false, 'reason' => 'bad_time', 'message' => $errs[0]]);
}
$end = zam_db_time($start->modify("+{$duration} minutes"));
$busy = zam_helper_conflict($pdo, $helperId, zam_db_time($start), $end);
api_json(['available' => !$busy, 'reason' => $busy ? 'busy' : null, 'helper' => $h['name'],
  'message' => $busy ? $h['name'] . ' is already booked at that time. Choose another time or helper.' : $h['name'] . ' is free at that time.']);
