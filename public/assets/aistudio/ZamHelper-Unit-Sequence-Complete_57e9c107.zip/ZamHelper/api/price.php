<?php
/** GET /api/price.php?service=cleaning&urgent=1&distance_km=3 | &lat=-15.4&lng=28.3&city=Lusaka&helper=4  ->  JSON price estimate. */
require __DIR__ . '/../includes/bootstrap.php';
api_method('GET'); api_guard('price', 180, 60);
$services = zam_load_services($pdo);
$key = (string)($_GET['service'] ?? ''); if (!isset($services[$key])) api_json(['error' => 'unknown_service'], 400);
[$name, $base, $perKm] = $services[$key];
$urgent = !empty($_GET['urgent']) && $_GET['urgent'] !== '0';
$helperId = (int)(filter_var($_GET['helper'] ?? null, FILTER_VALIDATE_INT) ?: 0);
$city = substr(trim((string)($_GET['city'] ?? '')), 0, 80);
$distance = is_numeric($_GET['distance_km'] ?? null) ? (float)$_GET['distance_km'] : 0.0; $origin = null; $source = 'typed';
if (isset($_GET['lat'], $_GET['lng']) && zam_coords_ok($_GET['lat'], $_GET['lng'])) {
  [$olat, $olng, $label] = zam_origin($pdo, $helperId, $city);
  $distance = zam_road_km($olat, $olng, (float)$_GET['lat'], (float)$_GET['lng']); $origin = $label; $source = 'map_pin';
}
$p = zam_price($base, $perKm, $distance, $urgent);
api_json($p + ['service' => $key, 'service_name' => $name, 'per_km' => $perKm, 'distance_source' => $source, 'origin' => $origin, 'formatted_total' => money($p['total'])]);
