<?php
/** GET -> {unread, items[]} for the signed-in user.  POST (header X-CSRF-Token) {"action":"mark_read"} -> marks all read. */
require __DIR__ . '/../includes/bootstrap.php';
api_guard('notifications', 120, 60);
$u = current_user(); if (!$u || !$pdo) api_json(['error' => 'not_signed_in'], 401);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!hash_equals($_SESSION['csrf'] ?? '', (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''))) api_json(['error' => 'bad_csrf'], 403);
  $pdo->prepare('UPDATE notifications SET read_at=? WHERE user_id=? AND read_at IS NULL')->execute([zam_db_time(zam_now()), $u['id']]);
  api_json(['unread' => 0]);
}
api_method('GET');
$q = $pdo->prepare('SELECT id,event,message,link,read_at IS NULL AS unread,created_at FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 20'); $q->execute([$u['id']]);
api_json(['unread' => zam_unread_count((int)$u['id']), 'items' => array_map(fn($n) => ['id' => (int)$n['id'], 'message' => $n['message'], 'link' => $n['link'], 'unread' => (bool)$n['unread'], 'created_at' => $n['created_at']], $q->fetchAll())]);
