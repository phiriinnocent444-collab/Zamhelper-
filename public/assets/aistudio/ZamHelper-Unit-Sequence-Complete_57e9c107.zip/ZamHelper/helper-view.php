<?php
require __DIR__ . '/includes/bootstrap.php';
$id = (int)(filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT) ?: 0); $h = null; $reviews = [];
if ($pdo && $id) {
  try {
    $q = $pdo->prepare("SELECT h.id,h.name,h.city,h.skills,h.rating,h.review_count,h.photo_path,h.is_verified,GROUP_CONCAT(s.name ORDER BY s.name SEPARATOR ', ') AS service_names
      FROM helpers h LEFT JOIN helper_services hs ON hs.helper_id=h.id LEFT JOIN services s ON s.id=hs.service_id
      WHERE h.id=? AND h.is_active=1 AND h.is_verified=1 AND h.verification_status='verified' GROUP BY h.id");
    $q->execute([$id]); $h = $q->fetch();
    if ($h) { $r = $pdo->prepare('SELECT r.rating,r.comment,r.created_at,u.name AS customer FROM reviews r JOIN users u ON u.id=r.customer_user_id WHERE r.helper_id=? AND r.is_hidden=0 ORDER BY r.id DESC LIMIT 20'); $r->execute([$id]); $reviews = $r->fetchAll(); }
  } catch (Throwable $e) {}
}
if (!$h) { http_response_code(404); }
$pageTitle = $h ? $h['name'] . ' · ZamHelper' : 'Helper not found';
require __DIR__ . '/includes/header.php'; ?>
<?php if (!$h): ?><section class="page-hero"><h1>Helper not found.</h1><p>This profile is not available.</p><a class="btn btn-primary" href="helpers.php">See all helpers</a></section>
<?php else: $photo = zam_photo_url($h['photo_path']); $n = (int)$h['review_count']; ?>
<section class="page-hero helper-hero"><?php if ($photo): ?><img class="helper-photo helper-photo-lg" src="<?= e($photo) ?>" alt="Photo of <?= e($h['name']) ?>" width="120" height="120"><?php endif ?><div class="eyebrow">✓ VERIFIED HELPER · <?= e(strtoupper($h['city'])) ?></div><h1><?= e($h['name']) ?></h1><p><?= $n ? '<b>' . zam_stars((float)$h['rating']) . ' ' . number_format((float)$h['rating'], 1) . '</b> from ' . $n . ' review' . ($n === 1 ? '' : 's') : 'New on ZamHelper. No reviews yet.' ?></p><a class="btn btn-primary" href="book.php?helper=<?= (int)$h['id'] ?>">Request this helper ↗</a></section>
<section class="section"><div class="apply-card"><h2>Services</h2><p><?= e($h['service_names'] ?: 'General services') ?></p><h2>About</h2><p><?= nl2br(e($h['skills'])) ?></p>
<h2>Reviews</h2><?php if (!$reviews): ?><p>No reviews yet. Reviews appear here after customers complete a job.</p><?php else: foreach ($reviews as $rv): ?><article class="review"><div class="review-top"><span class="stars" aria-label="<?= (int)$rv['rating'] ?> out of 5"><?= zam_stars((float)$rv['rating']) ?></span> <b><?= e(zam_first_name_initial($rv['customer'])) ?></b> <small><?= e(substr($rv['created_at'], 0, 10)) ?></small></div><?php if ($rv['comment'] !== ''): ?><p><?= nl2br(e($rv['comment'])) ?></p><?php endif ?></article><?php endforeach; endif ?></div></section>
<?php endif ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
