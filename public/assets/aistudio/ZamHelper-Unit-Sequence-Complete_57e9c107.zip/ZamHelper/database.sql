CREATE DATABASE IF NOT EXISTS zamhelper CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE zamhelper;
CREATE TABLE IF NOT EXISTS services (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, service_key VARCHAR(40) NOT NULL UNIQUE,
 name VARCHAR(120) NOT NULL, description VARCHAR(500) NOT NULL DEFAULT '', base_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
 per_km_rate DECIMAL(10,2) NOT NULL DEFAULT 0, is_active TINYINT(1) NOT NULL DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS helpers (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NULL UNIQUE, name VARCHAR(100) NOT NULL, phone VARCHAR(24) NOT NULL,
 city VARCHAR(80) NOT NULL, skills TEXT NOT NULL, rating DECIMAL(2,1) NOT NULL DEFAULT 5.0,
 is_verified TINYINT(1) NOT NULL DEFAULT 0, verification_status ENUM('unsubmitted','pending','verified','rejected') NOT NULL DEFAULT 'unsubmitted', verification_notes VARCHAR(500) NULL, is_available TINYINT(1) NOT NULL DEFAULT 1,
 is_active TINYINT(1) NOT NULL DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 review_count INT UNSIGNED NOT NULL DEFAULT 0, photo_path VARCHAR(190) NULL, base_lat DECIMAL(9,6) NULL, base_lng DECIMAL(9,6) NULL
);
CREATE TABLE IF NOT EXISTS helper_services (
 helper_id INT UNSIGNED NOT NULL, service_id INT UNSIGNED NOT NULL, PRIMARY KEY(helper_id,service_id),
 FOREIGN KEY(helper_id) REFERENCES helpers(id) ON DELETE CASCADE, FOREIGN KEY(service_id) REFERENCES services(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS bookings (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, customer_user_id BIGINT UNSIGNED NULL, helper_id INT UNSIGNED NULL, distance_km DECIMAL(7,2) NOT NULL DEFAULT 0, payment_status ENUM('not_required','unpaid','pending','paid','failed','refunded') NOT NULL DEFAULT 'unpaid', booking_code VARCHAR(32) NOT NULL UNIQUE,
 customer_name VARCHAR(100) NOT NULL, phone VARCHAR(24) NOT NULL, city VARCHAR(80) NOT NULL, area VARCHAR(100) NOT NULL DEFAULT '',
 service_key VARCHAR(40) NOT NULL, details VARCHAR(1200) NOT NULL DEFAULT '', is_urgent TINYINT(1) NOT NULL DEFAULT 0,
 estimated_fee DECIMAL(10,2) NOT NULL DEFAULT 0, status ENUM('pending','contacted','confirmed','in_progress','completed','cancelled') NOT NULL DEFAULT 'pending',
 created_at DATETIME NOT NULL, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 scheduled_start DATETIME NULL, duration_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 120, job_lat DECIMAL(9,6) NULL, job_lng DECIMAL(9,6) NULL,
 INDEX idx_bookings_status(status), INDEX idx_bookings_created(created_at), INDEX idx_bookings_helper_time(helper_id,scheduled_start)
);
INSERT IGNORE INTO services(service_key,name,description,base_fee,per_km_rate) VALUES
('cleaning','Cleaning','House cleaning and deep cleaning.',180,0),
('laundry','Laundry & ironing','Washing, drying and ironing, returned fresh.',120,0),
('errands','Shopping & errands','Groceries, pharmacy pickups and other errands.',100,8),
('delivery','Small deliveries','Parcels and packages taken where they need to go.',100,8),
('repairs','Minor repairs & assembly','Small fixes and furniture assembly.',200,0),
('gardening','Yard & garden work','Tidying, weeding and garden upkeep.',150,0),
('tutoring','Tutoring','Lessons and homework help.',150,0),
('home_assistance','Home assistance','Everyday help around the house.',150,0),
('moving','Moving & lifting','Help with moving and heavy lifting.',250,0),
('other','Other everyday tasks','Something else on your list? Tell us.',150,0);


CREATE TABLE IF NOT EXISTS helper_applications (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL, phone VARCHAR(24) NOT NULL, city VARCHAR(80) NOT NULL,
 skills VARCHAR(1200) NOT NULL, status ENUM('new','reviewing','approved','declined') NOT NULL DEFAULT 'new',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, INDEX idx_application_status(status)
);


CREATE TABLE IF NOT EXISTS users (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL, email VARCHAR(190) NULL UNIQUE, phone VARCHAR(24) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL, role ENUM('customer','helper','admin') NOT NULL DEFAULT 'customer',
 is_active TINYINT(1) NOT NULL DEFAULT 1, phone_verified_at DATETIME NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS payment_enquiries (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 booking_id BIGINT UNSIGNED NOT NULL,
 customer_user_id BIGINT UNSIGNED NOT NULL,
 booking_code VARCHAR(32) NOT NULL,
 amount DECIMAL(10,2) NOT NULL,
 payer_phone VARCHAR(24) NOT NULL,
 status ENUM('requested','instructions_sent','paid','cancelled') NOT NULL DEFAULT 'requested',
 verified_reference VARCHAR(120) NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_payment_enquiry_status(status),
 CONSTRAINT fk_payment_enquiry_booking FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE RESTRICT,
 CONSTRAINT fk_payment_enquiry_user FOREIGN KEY (customer_user_id) REFERENCES users(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS verification_documents (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, helper_id INT UNSIGNED NOT NULL,
 document_type ENUM('national_id','police_clearance','certificate','other') NOT NULL,
 private_path VARCHAR(255) NOT NULL, original_name VARCHAR(190) NOT NULL,
 status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending', reviewed_by BIGINT UNSIGNED NULL,
 review_note VARCHAR(500) NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(helper_id) REFERENCES helpers(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS audit_logs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, actor_user_id BIGINT UNSIGNED NULL,
 action VARCHAR(100) NOT NULL, entity_type VARCHAR(60) NOT NULL, entity_id VARCHAR(80) NOT NULL,
 metadata JSON NULL, ip_hash CHAR(64) NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_audit_entity(entity_type,entity_id)
);

CREATE TABLE IF NOT EXISTS reviews (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, booking_id BIGINT UNSIGNED NOT NULL UNIQUE, helper_id INT UNSIGNED NOT NULL,
 customer_user_id BIGINT UNSIGNED NOT NULL, rating TINYINT UNSIGNED NOT NULL, comment VARCHAR(600) NOT NULL DEFAULT '',
 is_hidden TINYINT(1) NOT NULL DEFAULT 0, created_at DATETIME NOT NULL,
 CONSTRAINT chk_review_rating CHECK (rating BETWEEN 1 AND 5),
 FOREIGN KEY(booking_id) REFERENCES bookings(id) ON DELETE CASCADE, FOREIGN KEY(helper_id) REFERENCES helpers(id) ON DELETE CASCADE,
 INDEX idx_reviews_helper(helper_id,is_hidden,created_at)
);
CREATE TABLE IF NOT EXISTS notifications (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL, booking_id BIGINT UNSIGNED NULL,
 event VARCHAR(40) NOT NULL, message VARCHAR(300) NOT NULL, link VARCHAR(190) NULL, read_at DATETIME NULL, created_at DATETIME NOT NULL,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE, INDEX idx_notifications_user(user_id,read_at,created_at)
);
CREATE TABLE IF NOT EXISTS rate_limits (
 bucket CHAR(64) PRIMARY KEY, hits INT UNSIGNED NOT NULL DEFAULT 0, window_start DATETIME NOT NULL
);
