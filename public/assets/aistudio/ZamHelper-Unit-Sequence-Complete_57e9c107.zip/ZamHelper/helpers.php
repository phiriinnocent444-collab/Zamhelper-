<?php
require __DIR__ . '/includes/bootstrap.php';
$pageTitle = 'Find a local helper'; $pageScripts = ['assets/helpers-live.js'];
$services = zam_load_services($pdo);
$q = trim((string)($_GET['q'] ?? '')); $sort = in_array($_GET['sort'] ?? '', ['rating', 'name', 'city'], true) ? $_GET['sort'] : 'rating';
$svc = isset($services[$_GET['service'] ?? '']) ? $_GET['service'] : ''; $page = max(1, (int)($_GET['page'] ?? 1));
$r = zam_list_helpers($pdo, $q, $svc, $sort, $page); $shown = $r['items']; $total = $r['total']; $pages = $r['pages']; $page = $r['page']; $allCount = $r['all_count'];
function hq($o) { return '?' . http_build_query(array_filter($o, fn($v) => $v !== '' && $v !== null)); }
function zam_helper_card(array $h): string {
  $photo = zam_photo_url($h['photo_path']); $n = (int)$h['review_count'];
  $avatar = $photo ? '<img class="helper-photo" src="' . e($photo) . '" alt="" width="64" height="64" loading="lazy">' : '<div class="helper-avatar">' . e(strtoupper(substr($h['name'], 0, 1))) . '</div>';
  $rating = $n ? '★ ' . number_format((float)$h['rating'], 1) . ' <small>(' . $n . ')</small>' : '<small>New</small>';
  return '<article class="helper-card">' . $avatar . '<div class="helper-meta"><span class="pill">' . (!empty($h['is_verified']) ? '✓ Verified' : 'Local helper') . '</span><span class="rating">' . $rating . '</span></div><h3>' . e($h['name']) . '</h3><p>' . e($h['city']) . ' · ' . e($h['service_names'] ?: 'General services') . '</p>'
    . (!empty($h['busy_now']) ? '<p class="busy-tag">Busy right now. You can still book a later time.</p>' : '')
    . '<a class="text-link" href="book.php?helper=' . (int)$h['id'] . '">Request this helper →</a> <a class="text-link" href="helper-view.php?id=' . (int)$h['id'] . '">Profile &amp; reviews</a></article>';
}
require __DIR__ . '/includes/header.php'; ?>
<section class="page-hero"><div class="eyebrow">LOCAL SKILLS. REAL PEOPLE.</div><h1>Meet your next <span class="lime">go-to helper.</span></h1><p>Browse local service providers and contact our team to confirm availability before a job is assigned.</p><a class="btn btn-primary" href="book.php">Request a helper ↗</a></section>
<section class="section helpers-section"><div class="section-head"><div><div class="eyebrow">THE HELPER NETWORK</div><h2>People who get it done.</h2></div><span class="pill" id="helperCount"><?= $total ?> listed helpers</span></div>
<form method="get" class="drawer-search helper-filter" id="helperForm" role="search"><input type="search" name="q" value="<?= e($q) ?>" placeholder="Search by name, city or service" aria-label="Search helpers"><select name="service" aria-label="Service"><option value="">All services</option><?php foreach ($services as $k => $s): ?><option value="<?= e($k) ?>"<?= $svc === $k ? ' selected' : '' ?>><?= e($s[0]) ?></option><?php endforeach ?></select><select name="sort" aria-label="Sort by"><option value="rating"<?= $sort == 'rating' ? ' selected' : '' ?>>Sort: Rating</option><option value="name"<?= $sort == 'name' ? ' selected' : '' ?>>Sort: Name</option><option value="city"<?= $sort == 'city' ? ' selected' : '' ?>>Sort: City</option></select><button type="submit">Search</button></form>
<div id="helperResults" aria-live="polite">
<?php if (!$allCount): ?><div class="empty-state"><div class="empty-icon">✳</div><h3>Our network is growing.</h3><p>Helper profiles will appear here when they are added by the team. You can still send a request now.</p><a class="btn btn-primary" href="book.php">Request a service ↗</a></div>
<?php elseif (!$total): ?><div class="empty-state"><div class="empty-icon">✳</div><h3>No helpers match your search.</h3><p>Try a different name, city or service, or clear the filters.</p><a class="btn btn-primary" href="helpers.php">Show all helpers</a></div>
<?php else: ?><div class="helper-grid"><?php foreach ($shown as $h) echo zam_helper_card($h); ?></div><?php if ($pages > 1): ?><nav class="pager" aria-label="Pages"><?php for ($i = 1; $i <= $pages; $i++): ?><a href="<?= e(hq(['q' => $q, 'service' => $svc, 'sort' => $sort, 'page' => $i])) ?>"<?= $i == $page ? ' aria-current="page"' : '' ?>><?= $i ?></a><?php endfor ?></nav><?php endif ?><?php endif ?></div></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
