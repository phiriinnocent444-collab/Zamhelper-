# ZamHelper — reverse-engineered marketplace rebuild

This project adapts useful product patterns from the supplied YouDate platform into ZamHelper's own service-marketplace domain. It does **not** reuse YouDate's proprietary source code, dating features, database dump, translations, user records or media.

## Product mapping

- Dating profiles / profile discovery → local helper profiles and skills.
- Likes / conversations → service request and direct WhatsApp follow-up.
- Paid / premium interaction concepts → transparent indicative service fee and optional urgent surcharge.
- User categories / profile fields → service categories, cities, availability and verification.
- Platform admin concepts → operations overview (currently intentionally not public-ready).

## Implemented marketplace features

- Responsive ZamHelper landing page, service cards and verified-helper directory.
- Customer and helper account registration/sign-in with password hashing, session ID rotation, role checks, CSRF protection and basic session-based login throttling.
- Customer dashboard for account-linked bookings; helper workspace for profile details, service selection and verification submissions.
- Private verification-document upload (PDF/JPG/PNG, max 5 MB) to a directory outside the project web root by default; files are not exposed through a public URL.
- Admin review of helper verification, profile activation, booking status updates, assignment of verified/available helpers and payment-request record review.
- Booking requests with unique references, optional account ownership, requested-helper validation, service rates loaded from MySQL, customer-entered indicative travel distance and database-configured per-kilometre rates; urgent requests apply a 1.25 multiplier.
- WhatsApp-first payment enquiries with a saved enquiry reference and manual payment confirmation by an admin after checking the official merchant channel.
- Audit log entries for account and sensitive admin/payment actions, prepared SQL statements, basic security headers and private upload permissions.
- WhatsApp handoff to **+260 772 300 053**.

## Payment handling status

**Live Airtel Money and MTN MoMo API collection is not enabled in this package.** Zambia merchant onboarding, the correct provider product, credentials, API environment, callback URLs and provider-specific signature rules must be supplied and tested before real payment requests can be sent to either network. The current implementation records a WhatsApp payment enquiry and opens a pre-filled message to +260 772 300 053; an administrator must verify receipt through the official merchant channel before marking it paid. The site does not ask customers to select Airtel/MTN inside the website and does not call either payment API. Do not treat a screenshot or customer-entered reference as proof of payment. Never request a PIN or OTP.

## Verification and pricing limitations

- Admin approval is a manual trust decision; verify identity documents outside the application before approving a helper.
- Document uploads are stored privately, but the server's `ZAM_PRIVATE_UPLOAD_DIR` must be configured to a writable directory outside the public web root on the production host.
- Distance is entered by the customer for an estimate, not automatically routed or GPS-verified. Confirm actual route distance and the final quote with the customer.
- Account phone verification, password-reset email/SMS, dispute/refund handling, automated payout, and production-grade fraud detection are not implemented.
- Do not expose this site publicly until HTTPS, a least-privilege database account, backups, monitoring, retention policy and a security review are in place.

## Run locally (PC / WSL / XAMPP)

1. Install PHP 8.1+ with PDO MySQL, MySQL/MariaDB and a web server.
2. Copy this folder into your web root, e.g. `/var/www/html/zamhelper` or `htdocs/zamhelper`.
3. Import `database.sql` in phpMyAdmin or run `mysql -u root -p < database.sql`. If you already have an older ZamHelper database, back it up first, import the current SQL to create new tables, then run `upgrade-existing.sql` exactly once to add columns to existing tables. Do not run the upgrade script on a fresh database.
4. Set database credentials using environment variables `ZAM_DB_HOST`, `ZAM_DB_NAME`, `ZAM_DB_USER`, `ZAM_DB_PASS`. For admin access, generate a password hash with `php -r "echo password_hash('your-long-password', PASSWORD_DEFAULT), PHP_EOL;"` and set it as `ZAM_ADMIN_PASSWORD_HASH`. See `.env.example`.
5. Generate a long random admin password hash with the command above and set `ZAM_ADMIN_PASSWORD_HASH` in the PHP server environment before visiting `/admin/`. For document uploads, set `ZAM_PRIVATE_UPLOAD_DIR` to a writable private directory outside the web root.
6. Open `http://localhost/zamhelper/`.

## Run on Android Termux

```sh
pkg update && pkg install php mariadb unzip
mkdir -p ~/www && cd ~/www
# Extract ZamHelper.zip into this directory, then:
cd ZamHelper
php -S 127.0.0.1:8080
```
Open `http://127.0.0.1:8080`. PHP's built-in server is for development only. For MySQL-backed features, configure MariaDB and import `database.sql`. To make the site public on the internet, use a real host/domain with HTTPS; a local Termux server alone is not public hosting.

## Remaining production work — do not skip

- Password recovery, phone OTP verification, disputes/refunds, automated payouts and production-grade fraud detection are not implemented. The admin area uses a configured password hash separate from customer/helper accounts.
- Distance is customer-entered for indicative pricing; route calculation and calendar-slot scheduling are not implemented.
- Configure HTTPS, secure cookies, backups, logging, secrets outside source, privacy/retention policy and error handling.
- Confirm final prices, availability and mobile-money payment instructions manually. Never collect a mobile-money PIN or OTP.
- Have the site security-reviewed before storing real customer data.

## Important limitations

- Estimates are fixed indicative service rates; they are not dynamic market quotes and distance-based pricing is not applied in the booking form yet.
- WhatsApp handoff requires the customer to tap Send in WhatsApp; the site does not send messages automatically or process Airtel Money/MTN MoMo payments.
- Deploy under a dedicated least-privilege database user with HTTPS, backups, logging and a reviewed privacy policy.

## Notes

This is a working starter scaffold rather than a claim that the original YouDate application has been transformed internally or that the system is production-ready. It uses original ZamHelper-specific PHP, SQL and CSS. The YouDate archive served as a reference for feature mapping and product structure.


## Concurrent booking protection (CSMA/CD-inspired concept)

The booking workflow now protects helper assignment against simultaneous requests using **MySQL transactions and row-level locks** (`SELECT ... FOR UPDATE`). If two customers or an administrator try to assign the same helper while that helper already has an active assigned job, the later request is rejected rather than creating a conflicting assignment. The public helper list and admin assignment choices also hide helpers who have active jobs. A helper becomes eligible again when their assigned booking is marked `completed` or `cancelled`.

This is inspired by the idea of detecting contention and handling a retry, but it is **not Ethernet CSMA/CD**: the browser does not simulate random collisions. MySQL is the authority for concurrent requests. The current booking form does not capture a requested date/time, so this version allows only one active assigned job per helper; it does not implement calendar-based overlapping time slots. Requests without a selected helper can still be submitted and assigned by an administrator later.

**Important:** concurrency protection requires the MySQL database to be connected and the tables to use InnoDB (the supplied `database.sql` uses InnoDB by default on typical MySQL/MariaDB installations). If database setup fails, do not treat a WhatsApp-prepared request as a saved booking.


## Concurrent booking protection and local setup

- `book.php` wraps selected-helper booking creation in a MySQL transaction and locks the selected helper row with `SELECT ... FOR UPDATE`. It then checks for another active booking (status not `completed` or `cancelled`) whose time window overlaps the requested one before inserting. Windows are `scheduled_start` + `duration_minutes`; an "as soon as possible" job is open-ended until completed or cancelled.
- `admin/index.php` checks helper availability when assigning a booking. `helpers.php` excludes helpers with active assigned jobs from the public list.

### XAMPP setup
1. Extract the `ZamHelper` folder into `C:\xampp\htdocs\` (result: `C:\xampp\htdocs\ZamHelper\`).
2. Start Apache and MySQL in XAMPP. Import `database.sql` into phpMyAdmin and configure `config.php` with the local database name/user/password.
3. Open `http://localhost/ZamHelper/book.php` for booking tests.
4. Test booking concurrency using two separate browser sessions and the same preferred helper. One active assigned booking should be accepted; a competing request should be rejected. Back up the database before testing.

For row locks to work, relevant tables must use InnoDB. Availability is calendar-based: a helper can hold several bookings as long as their time windows do not overlap (see `includes/scheduling.php`).

## Site features

- **Entity-relationship diagram**: `docs/er-diagram.png`, `docs/er-diagram.svg` and `docs/er-diagram.md` (Mermaid).
- **Menu, settings and helper search**: hamburger drawer, settings panel (Colors, One column, Big UI, Calm mode; saved in the browser) and search/sort/pagination on the helpers page. Dark mode inverts the whole page, so contrast is preserved everywhere; brand colours shift slightly.

### Tests
`php tests/run.php` (needs MySQL/MariaDB; creates and drops a throwaway database `zamhelper_test`; set `ZAM_DB_USER` / `ZAM_DB_PASS` if root has no password login). It covers access rules, the service catalogue, the upgrade script, page rendering and brand contrast.

## Brand theme and services

- The look follows the ZamHelper circular badge design (`assets/zamhelper-badge.webp`): royal blue and brand green, the Z-and-hands mark, and the tagline “Reliable Help, Anytime”. Colours are CSS variables in the last `:root` block of `assets/style.css`. The home hero shows the badge and a service chip row that includes Moving & lifting.
- **Services** live in one place, `includes/services.php`: Cleaning, Laundry & ironing, Shopping & errands, Small deliveries, Minor repairs & assembly, Yard & garden work, Tutoring, Home assistance, Moving & lifting and Other everyday tasks. The home page, booking form and database seed all follow it, and `php tests/run.php` fails if they ever differ.
- **Fees for the new services (laundry 120, deliveries 100 + 8/km, tutoring 150, home assistance 150) are placeholders.** Change them in the `services` table. Existing installs: run the “services-upsert” block at the end of `upgrade-existing.sql` (safe to repeat; it keeps any fees you already changed).
- The tests also check text contrast of the brand colours against WCAG AA (4.5:1).


## Unit sequence implementation

The project brings the unit sequence into one application: requirements and acceptance criteria; responsive UI/UX; relational database/ER modelling; HTML/CSS/vanilla JavaScript; PHP request handling; PDO/MySQL persistence; sessions and access control; secure form handling; indicative distance pricing and urgent surcharge; booking concurrency protection; WhatsApp payment enquiries; testing, dependability, risk management, documentation, deployment and maintenance.

- `docs/er-diagram.svg` and `docs/er-diagram.png` show the database model; `docs/er-diagram.md` contains editable Mermaid source. `docs/architecture-diagram.mmd` and `docs/use-case-diagram.mmd` provide additional editable diagrams.
- `docs/unit-sequence-mapping.md` maps course concepts to the exact files and suggested tests.

## WhatsApp-only payment flow

The customer selects their own confirmed booking and prepares a payment enquiry. ZamHelper records the enquiry, then opens WhatsApp at **+260 772 300 053** with the booking code, service and indicative amount. The customer must review and send the message. The administrator marks payment as received only after independently verifying the transaction; no gateway collection or automatic verification is claimed.

## Web technology features (v2)

Run `upgrade-v2.sql` once on an existing database (fresh installs already get everything from `database.sql`).

| Feature | Where | Notes |
|---|---|---|
| **Scheduled bookings** | `book.php`, `includes/scheduling.php` | "As soon as possible" or a date/time (06:00-20:59, at least 1 h ahead, up to 90 days) plus a duration. A helper cannot be double-booked: overlapping active bookings are refused inside a transaction that locks the helper row. Times are Africa/Lusaka. An active "as soon as possible" job keeps a helper busy until it is completed or cancelled. |
| **Fetch + JSON** | `api/price.php`, `api/availability.php`, `api/helpers.php`, `api/notifications.php` | Live price (server is the single source of truth), live helper availability, live helper search and unread count. Every page still works without JavaScript. |
| **Installable app (PWA)** | `manifest.webmanifest`, `sw.js`, `offline.html` | Works on HTTPS (or localhost). Caches only static files; pages, API, admin and payments are never cached, so no private data is stored offline. |
| **Ratings and reviews** | `review.php`, `helper-view.php` | One review per completed booking, by that customer only. Admin can hide abusive reviews; hidden ones stop counting. |
| **Helper photos** | `helper/profile.php`, `includes/photos.php` | Needs the PHP **GD** extension. Photos are re-encoded to a 480x480 JPEG (strips EXIF/GPS and hidden payloads) and stored in `uploads/helpers/` where scripts cannot run. Admin can remove a photo. |
| **Map (Leaflet + OpenStreetMap)** | booking page, helper profile | Leaflet is bundled in `assets/vendor/leaflet`. Customers drop a pin; the server computes the road-distance estimate (straight line x 1.3) from the helper's base area, or the city centre. Tiles come from OpenStreetMap (light use; keep the attribution). Heavy traffic needs a commercial tile provider. |
| **Notifications** | `includes/notify.php`, `notifications.php`, bell in the header | In-app for every booking event. Email is sent if the user has an email and `ZAM_MAIL_FROM` is set. WhatsApp has no free official sending API, so admin gets ready-made "WhatsApp customer / helper" links per booking. |
| **Rate limiting** | `throttle()` in `includes/bootstrap.php` | Database-backed per IP (and per account for sign-in): login, register, booking, helper application, payment enquiry, review, photo upload, admin sign-in and all APIs. Uses `REMOTE_ADDR`; behind a proxy, configure the web server to set the real client IP. |
| **Payments** | `payments/webhook.php` | Signed, idempotent receiving end only. **Live MoMo/Airtel collection is not built**: see `docs/payments-integration.md`. |

Optional environment variables: `ZAM_MAIL_FROM`, `ZAM_PAYMENT_WEBHOOK_SECRET` (see `.env.example`).
Tests: `php tests/run.php` (needs MySQL/MariaDB and PHP GD for the photo tests).
