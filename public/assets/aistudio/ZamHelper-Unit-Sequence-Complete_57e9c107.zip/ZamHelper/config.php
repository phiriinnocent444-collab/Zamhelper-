<?php
// Keep production secrets in environment variables; never commit real credentials.
return [
 'db_host' => getenv('ZAM_DB_HOST') ?: '127.0.0.1',
 'db_name' => getenv('ZAM_DB_NAME') ?: 'zamhelper',
 'db_user' => getenv('ZAM_DB_USER') ?: 'root',
 'db_pass' => getenv('ZAM_DB_PASS') ?: '',
 'whatsapp' => '260772300053',
 'app_name' => 'ZamHelper',
 'admin_password_hash' => getenv('ZAM_ADMIN_PASSWORD_HASH') ?: '',
];
