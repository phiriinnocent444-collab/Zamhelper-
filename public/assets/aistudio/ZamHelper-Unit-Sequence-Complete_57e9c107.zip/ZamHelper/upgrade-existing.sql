-- Run this ONLY when upgrading an existing older ZamHelper database.
-- First back up the database, then import the current database.sql so the new tables exist.
-- These ALTER statements are intentionally one-time; do not run repeatedly.
USE zamhelper;
ALTER TABLE helpers
  ADD COLUMN user_id BIGINT UNSIGNED NULL UNIQUE AFTER id,
  ADD COLUMN verification_status ENUM('unsubmitted','pending','verified','rejected') NOT NULL DEFAULT 'unsubmitted' AFTER is_verified,
  ADD COLUMN verification_notes VARCHAR(500) NULL AFTER verification_status;
ALTER TABLE bookings
  ADD COLUMN customer_user_id BIGINT UNSIGNED NULL AFTER id,
  ADD COLUMN helper_id INT UNSIGNED NULL AFTER customer_user_id,
  ADD COLUMN distance_km DECIMAL(7,2) NOT NULL DEFAULT 0 AFTER helper_id,
  ADD COLUMN payment_status ENUM('not_required','unpaid','pending','paid','failed','refunded') NOT NULL DEFAULT 'unpaid' AFTER estimated_fee;

-- services-upsert-start (safe to repeat; renames services and adds new ones, keeps any fees you changed)
INSERT INTO services(service_key,name,description,base_fee,per_km_rate) VALUES
('cleaning','Cleaning','House cleaning and deep cleaning.',180,0),
('laundry','Laundry & ironing','Washing, drying and ironing, returned fresh.',120,0),
('errands','Shopping & errands','Groceries, pharmacy pickups and other errands.',100,8),
('delivery','Small deliveries','Parcels and packages taken where they need to go.',100,8),
('repairs','Minor repairs & assembly','Small fixes and furniture assembly.',200,0),
('gardening','Yard & garden work','Tidying, weeding and garden upkeep.',150,0),
('tutoring','Tutoring','Lessons and homework help.',150,0),
('home_assistance','Home assistance','Everyday help around the house.',150,0),
('moving','Moving & lifting','Help with moving and heavy lifting.',250,0),
('other','Other everyday tasks','Something else on your list? Tell us.',150,0)
ON DUPLICATE KEY UPDATE name=VALUES(name),description=VALUES(description);
-- services-upsert-end
