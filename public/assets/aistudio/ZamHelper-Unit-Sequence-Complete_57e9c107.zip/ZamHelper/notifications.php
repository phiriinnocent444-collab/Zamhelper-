<?php
require __DIR__ . '/includes/bootstrap.php';
$u = require_login(); $pageTitle = 'Notifications'; $items = [];
if ($pdo) {
  try {
    $q = $pdo->prepare('SELECT id,message,link,read_at IS NULL AS unread,created_at FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 50'); $q->execute([$u['id']]); $items = $q->fetchAll();
    if ($_SERVER['REQUEST_METHOD'] === 'POST') { csrf_check(); $pdo->prepare('UPDATE notifications SET read_at=? WHERE user_id=? AND read_at IS NULL')->execute([zam_db_time(zam_now()), $u['id']]); header('Location: notifications.php'); exit; }
  } catch (Throwable $e) {}
}
function zam_safe_link(?string $l): string { return ($l && preg_match('/^[a-z0-9_\-]+\.php(\?[a-z0-9_=&\-]*)?$/i', $l)) ? $l : 'dashboard.php'; }
require __DIR__ . '/includes/header.php'; ?>
<section class="page-hero"><div class="eyebrow">UPDATES</div><h1>Your <span class="lime">notifications.</span></h1><p>Booking updates appear here. If you added an email address to your account, we also email you when mail is set up on the server.</p></section>
<section class="section"><?php if (!$items): ?><div class="empty-state"><h3>Nothing yet</h3><p>Updates about your bookings will show up here.</p></div><?php else: ?>
<form method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><button class="btn btn-dark btn-small">Mark all as read</button></form>
<ul class="notif-list"><?php foreach ($items as $n): ?><li class="<?= $n['unread'] ? 'is-unread' : '' ?>"><a href="<?= e(zam_safe_link($n['link'])) ?>"><?= e($n['message']) ?></a><small><?= e($n['created_at']) ?></small></li><?php endforeach ?></ul><?php endif ?></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
