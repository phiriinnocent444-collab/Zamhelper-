<?php
require __DIR__ . '/includes/bootstrap.php';
$pageTitle = 'Book a service'; $zamUseMap = true; $pageScripts = ['assets/book.js'];
$services = zam_load_services($pdo);
$user = current_user();
$selected = $_GET['service'] ?? 'cleaning'; if (!isset($services[$selected])) $selected = 'cleaning';
$requestedHelper = filter_var($_GET['helper'] ?? null, FILTER_VALIDATE_INT) ?: 0; $helperName = '';
if ($requestedHelper && $pdo) {
  try { $q = $pdo->prepare('SELECT name FROM helpers WHERE id=? AND is_active=1'); $q->execute([$requestedHelper]); $rh = $q->fetch(); if ($rh) $helperName = $rh['name']; else $requestedHelper = 0; }
  catch (Throwable $e) { $requestedHelper = 0; }
}
$urgent = !empty($_POST['urgent']);
$errors = []; $sent = false; $wa = ''; $code = '';
$now = zam_now(); $minSlot = $now->modify('+' . ZAM_MIN_NOTICE_MINUTES . ' minutes')->format('Y-m-d\TH:i'); $maxSlot = $now->modify('+' . ZAM_MAX_DAYS_AHEAD . ' days')->format('Y-m-d\TH:i');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  throttle_or_die('booking', 10, 3600);
  csrf_check();
  $name = trim($_POST['name'] ?? ''); $phone = trim($_POST['phone'] ?? ''); $city = trim($_POST['city'] ?? ''); $area = trim($_POST['area'] ?? '');
  $service = $_POST['service'] ?? 'other'; $details = trim($_POST['details'] ?? '');
  $distance = max(0, min(500, (float)($_POST['distance_km'] ?? 0))); $assignedHelper = 0;
  $requestedHelper = filter_var($_POST['helper_id'] ?? $requestedHelper, FILTER_VALIDATE_INT) ?: 0;
  $mode = ($_POST['when_mode'] ?? 'asap') === 'scheduled' ? 'scheduled' : 'asap';
  $duration = (int)($_POST['duration'] ?? ZAM_DEFAULT_DURATION); if (!zam_valid_duration($duration)) { $errors[] = 'Choose how long you need help for.'; $duration = ZAM_DEFAULT_DURATION; }
  $start = null; $scheduledStart = null;
  if ($mode === 'scheduled') {
    $start = zam_parse_slot((string)($_POST['when'] ?? ''));
    if (!$start) $errors[] = 'Choose a valid date and time.'; else { foreach (zam_slot_errors($start, $now) as $er) $errors[] = $er; $scheduledStart = zam_db_time($start); }
  }
  $jobLat = $jobLng = null;
  if (($_POST['job_lat'] ?? '') !== '' || ($_POST['job_lng'] ?? '') !== '') {
    if (zam_coords_ok($_POST['job_lat'] ?? null, $_POST['job_lng'] ?? null)) { $jobLat = round((float)$_POST['job_lat'], 6); $jobLng = round((float)$_POST['job_lng'], 6); }
    else $errors[] = 'The map pin must be inside Zambia. Clear it or move it.';
  }
  if ($name === '') $errors[] = 'Please enter your name.';
  if (!valid_phone($phone)) $errors[] = 'Enter a valid phone number.';
  if (strlen($name) > 100) $errors[] = 'Name is too long.';
  if (strlen($city) > 80 || strlen($area) > 100) $errors[] = 'Please shorten your location details.';
  if ($city === '') $errors[] = 'Please enter your city.';
  if (!isset($services[$service])) $errors[] = 'Choose a valid service.';
  if (strlen($details) > 1200) $errors[] = 'Job details must be under 1,200 characters.';
  if ($jobLat === null && (!is_numeric($_POST['distance_km'] ?? '0') || $distance < 0 || $distance > 500)) $errors[] = 'Enter an estimated travel distance between 0 and 500 km.';
  if ($requestedHelper) {
    if (!$pdo) $errors[] = 'Helper selection requires the database.';
    else {
      $hq = $pdo->prepare('SELECT h.id FROM helpers h JOIN helper_services hs ON hs.helper_id=h.id JOIN services s ON s.id=hs.service_id WHERE h.id=? AND h.is_active=1 AND h.is_verified=1 AND h.is_available=1 AND s.service_key=? LIMIT 1');
      $hq->execute([$requestedHelper, $service]);
      if (!$hq->fetchColumn()) $errors[] = 'That helper is not currently verified and available for this service.'; else $assignedHelper = $requestedHelper;
    }
  }
  if (!$errors) {
    if ($jobLat !== null) { [$olat, $olng] = zam_origin($pdo, $assignedHelper, $city); $distance = zam_road_km($olat, $olng, $jobLat, $jobLng); }
    $urgent = !empty($_POST['urgent']);
    $p = zam_price($services[$service][1], $services[$service][2] ?? 0, $distance, $urgent); $base = $p['base']; $travel = $p['travel']; $total = $p['total'];
    $createdAt = zam_db_time($now); [$winStart, $winEnd] = [$scheduledStart ?? $createdAt, zam_db_time(($start ?? $now)->modify("+{$duration} minutes"))];
    $code = booking_code();
    $preferred = $requestedHelper ? ($helperName ?: 'Selected helper') : 'Any available helper';
    $message = "ZAMHELPER SERVICE REQUEST\nBooking reference: $code\nName: $name\nPhone: $phone\nCity: $city\nArea: $area\n"
      . ($jobLat !== null ? 'Map pin: ' . zam_osm_link($jobLat, $jobLng) . "\n" : '')
      . "Service: {$services[$service][0]}\nWhen: " . zam_when_label($scheduledStart, $duration) . "\nRequested helper: $preferred\nBase service fee: " . money($base)
      . "\nEstimated distance: $distance km" . ($jobLat !== null ? ' (from map pin)' : '') . "\nTravel fee (indicative): " . money($travel)
      . "\nUrgent: " . ($urgent ? 'Yes (25% surcharge)' : 'No') . "\nEstimated total: " . money($total) . "\nJob details: $details\n\nPlease confirm availability, final quote and payment instructions.";
    if ($pdo) {
      try {
        $pdo->beginTransaction();
        // Lock the helper row so two simultaneous requests for the same helper are processed one after the other,
        // then reject the request if the helper already has an overlapping active booking.
        if ($assignedHelper) {
          $lock = $pdo->prepare('SELECT h.id FROM helpers h JOIN helper_services hs ON hs.helper_id=h.id JOIN services s ON s.id=hs.service_id WHERE h.id=? AND h.is_active=1 AND h.is_verified=1 AND h.is_available=1 AND s.service_key=? FOR UPDATE');
          $lock->execute([$assignedHelper, $service]);
          if (!$lock->fetchColumn()) { $pdo->rollBack(); $errors[] = 'That helper was just taken or is no longer available. Please choose another helper or submit without a preferred helper.'; }
          elseif (zam_helper_conflict($pdo, $assignedHelper, $winStart, $winEnd)) { $pdo->rollBack(); $errors[] = 'That helper is already booked at that time. Please choose another time or helper, or submit without a preferred helper.'; }
        }
        if (!$errors) {
          $st = $pdo->prepare('INSERT INTO bookings (booking_code,customer_user_id,helper_id,distance_km,customer_name,phone,city,area,service_key,details,is_urgent,estimated_fee,status,created_at,scheduled_start,duration_minutes,job_lat,job_lng) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
          $st->execute([$code, $user['id'] ?? null, $assignedHelper ?: null, $distance, $name, $phone, $city, $area, $service, $details, $urgent ? 1 : 0, $total, 'pending', $createdAt, $scheduledStart, $duration, $jobLat, $jobLng]);
          $newId = (int)$pdo->lastInsertId(); $pdo->commit();
          if ($user) zam_notify((int)$user['id'], 'booking_created', "We received booking $code. ZamHelper will confirm it with you on WhatsApp.", 'dashboard.php', $newId);
        }
      } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); $errors[] = 'We could not save your request right now. Please try again in a moment.'; }
    }
    if (!$errors) { $wa = wa_link($message); $sent = true; }
  }
}
$estimateNow = zam_price($services[$selected][1], $services[$selected][2] ?? 0, (float)($_POST['distance_km'] ?? 0), $urgent)['total'];
$postedMode = ($_POST['when_mode'] ?? 'asap') === 'scheduled' ? 'scheduled' : 'asap';
require __DIR__ . '/includes/header.php'; ?>
<section class="booking-layout"><div class="booking-intro"><div class="eyebrow">YOUR TASK, HANDLED</div><h1>Let's get it<br><span class="lime">sorted.</span></h1><p>Tell us a little about the job. We'll prepare your request so you can continue with our team on WhatsApp.</p><div class="booking-points"><div><span>✓</span><p><b>Pick your time</b><small>Book as soon as possible, or choose a day and hour that suits you.</small></p></div><div><span>✓</span><p><b>Upfront estimate</b><small>See the estimated fee before sending.</small></p></div><div><span>✓</span><p><b>Human confirmation</b><small>Availability and final pricing are confirmed with you.</small></p></div></div><div class="estimate-note">Indicative rates only. Final price depends on job scope, distance, materials and helper availability.</div></div>
<div class="booking-form-wrap"><?php if ($sent): ?><div class="success-state"><div class="success-check">✓</div><div class="eyebrow">REQUEST PREPARED · <?= e($code ?: 'ZH-WHATSAPP') ?></div><h2>One step from <span class="lime-dark">sorted.</span></h2><p>Your request has been prepared. Continue to WhatsApp to send it to the ZamHelper team.</p><a class="btn btn-primary btn-full" target="_blank" rel="noopener" href="<?= e($wa) ?>">Send request on WhatsApp ↗</a><a class="text-link" href="book.php">Make another request</a></div><?php else: ?>
<?php if ($errors): ?><div class="form-errors"><b>Please check:</b><ul><?php foreach ($errors as $er): ?><li><?= e($er) ?></li><?php endforeach ?></ul></div><?php endif ?>
<form method="post" class="booking-form" id="bookForm" data-helper="<?= intval($requestedHelper) ?>" data-city-centres='<?= e(json_encode(array_map(fn($c) => [$c[1], $c[2]], ZAM_CITY_CENTRES))) ?>'>
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="helper_id" value="<?= intval($requestedHelper) ?>">
<input type="hidden" name="job_lat" id="job_lat" value="<?= e($_POST['job_lat'] ?? '') ?>"><input type="hidden" name="job_lng" id="job_lng" value="<?= e($_POST['job_lng'] ?? '') ?>">
<div class="form-head"><span>01</span><div><h2>Tell us about the job</h2><?php if ($helperName): ?><p>Preferred helper: <b><?= e($helperName) ?></b> (subject to availability).</p><?php endif ?><p>Fields marked * are required.</p></div></div>
<label>What do you need? *<select name="service" id="service" required><?php foreach ($services as $key => $s): ?><option value="<?= e($key) ?>" data-price="<?= $s[1] ?>" data-per-km="<?= $s[2] ?? 0 ?>" <?= ((($_POST['service'] ?? $selected) === $key) ? 'selected' : '') ?>><?= e($s[0]) ?> — <?= money($s[1]) ?>+</option><?php endforeach ?></select></label>
<fieldset class="when-box"><legend>When do you need help? *</legend>
<label class="when-opt"><input type="radio" name="when_mode" value="asap" <?= $postedMode === 'asap' ? 'checked' : '' ?>> <span><b>As soon as possible</b><small>We will contact you straight away.</small></span></label>
<label class="when-opt"><input type="radio" name="when_mode" value="scheduled" <?= $postedMode === 'scheduled' ? 'checked' : '' ?>> <span><b>Pick a date and time</b><small>Start times are 06:00–20:59, at least 1 hour from now.</small></span></label>
<div id="whenFields" <?= $postedMode === 'scheduled' ? '' : 'hidden' ?>><div class="form-row"><label>Start<input type="datetime-local" name="when" id="when" min="<?= e($minSlot) ?>" max="<?= e($maxSlot) ?>" step="900" value="<?= e($_POST['when'] ?? '') ?>"></label><label>How long?<select name="duration" id="duration"><?php foreach (ZAM_DURATIONS as $m => $label): ?><option value="<?= $m ?>" <?= ((int)($_POST['duration'] ?? ZAM_DEFAULT_DURATION) === $m) ? 'selected' : '' ?>><?= e($label) ?></option><?php endforeach ?></select></label></div></div>
<p class="avail-msg" id="availMsg" role="status" aria-live="polite" hidden></p></fieldset>
<div class="form-row"><label>Your name *<input name="name" required maxlength="100" value="<?= e($_POST['name'] ?? ($user['name'] ?? '')) ?>" placeholder="Full name"></label><label>Phone number *<input name="phone" required maxlength="20" value="<?= e($_POST['phone'] ?? ($user['phone'] ?? '')) ?>" placeholder="e.g. 097..." inputmode="tel"></label></div>
<div class="form-row"><label>City *<input name="city" id="city" required maxlength="80" value="<?= e($_POST['city'] ?? 'Lusaka') ?>" placeholder="e.g. Lusaka"></label><label>Area / neighbourhood<input name="area" maxlength="100" value="<?= e($_POST['area'] ?? '') ?>" placeholder="e.g. Kabulonga"></label></div>
<div class="map-box"><div class="map-head"><b>Where is the job?</b> <small>Tap the map to drop a pin. It is optional, and it sets the travel distance for you.</small></div><div id="pinMap" class="pin-map" aria-label="Map for choosing the job location"><noscript>The map needs JavaScript. You can type the distance below instead.</noscript></div><div class="map-actions"><button type="button" class="btn btn-dark btn-small" id="useLocation">Use my location</button><button type="button" class="btn btn-quiet-dark btn-small" id="clearPin" hidden>Clear pin</button></div><p class="map-note" id="mapNote" role="status" aria-live="polite">Map tiles © OpenStreetMap contributors. Your pin is only used for this request.</p></div>
<label>Estimated one-way travel distance (km)<input type="number" name="distance_km" id="distance_km" min="0" max="500" step="0.5" value="<?= e($_POST['distance_km'] ?? '0') ?>"><small id="distNote">Indicative estimate only. The team confirms the actual route and fee.</small></label>
<label>Describe the job<textarea name="details" rows="4" maxlength="1200" placeholder="What needs to be done? Add useful details."><?= e($_POST['details'] ?? '') ?></textarea></label>
<label class="urgent-option"><input type="checkbox" name="urgent" value="1" id="urgent" <?= $urgent ? 'checked' : '' ?>><span><b>I need this urgently</b><small>Applies a 25% urgent-request surcharge to the estimate.</small></span></label>
<div class="price-preview"><div><span>Estimated service fee</span><small id="priceNote">Final quote confirmed on WhatsApp</small></div><strong id="price" aria-live="polite">K<?= number_format($estimateNow, 2) ?></strong></div>
<button class="btn btn-primary btn-full" type="submit">Prepare WhatsApp request <span>↗</span></button><p class="form-legal">No payment is collected here. Never send passwords, PINs or mobile-money OTPs.</p></form><?php endif ?></div></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
