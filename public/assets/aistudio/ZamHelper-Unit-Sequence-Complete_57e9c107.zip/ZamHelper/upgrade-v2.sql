-- Run this ONLY when upgrading an existing ZamHelper database that already ran database.sql / upgrade-existing.sql.
-- Back up first. The ALTER statements are one-time (do not run twice). It adds: scheduled bookings, map pins,
-- helper photos and base location, ratings and reviews, in-app notifications and database-backed rate limiting.
USE zamhelper;
ALTER TABLE helpers
  ADD COLUMN review_count INT UNSIGNED NOT NULL DEFAULT 0,
  ADD COLUMN photo_path VARCHAR(190) NULL,
  ADD COLUMN base_lat DECIMAL(9,6) NULL,
  ADD COLUMN base_lng DECIMAL(9,6) NULL;
ALTER TABLE bookings
  ADD COLUMN scheduled_start DATETIME NULL,
  ADD COLUMN duration_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 120,
  ADD COLUMN job_lat DECIMAL(9,6) NULL,
  ADD COLUMN job_lng DECIMAL(9,6) NULL,
  ADD INDEX idx_bookings_helper_time(helper_id,scheduled_start);
CREATE TABLE IF NOT EXISTS reviews (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, booking_id BIGINT UNSIGNED NOT NULL UNIQUE, helper_id INT UNSIGNED NOT NULL,
 customer_user_id BIGINT UNSIGNED NOT NULL, rating TINYINT UNSIGNED NOT NULL, comment VARCHAR(600) NOT NULL DEFAULT '',
 is_hidden TINYINT(1) NOT NULL DEFAULT 0, created_at DATETIME NOT NULL,
 CONSTRAINT chk_review_rating CHECK (rating BETWEEN 1 AND 5),
 FOREIGN KEY(booking_id) REFERENCES bookings(id) ON DELETE CASCADE, FOREIGN KEY(helper_id) REFERENCES helpers(id) ON DELETE CASCADE,
 INDEX idx_reviews_helper(helper_id,is_hidden,created_at)
);
CREATE TABLE IF NOT EXISTS notifications (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL, booking_id BIGINT UNSIGNED NULL,
 event VARCHAR(40) NOT NULL, message VARCHAR(300) NOT NULL, link VARCHAR(190) NULL, read_at DATETIME NULL, created_at DATETIME NOT NULL,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE, INDEX idx_notifications_user(user_id,read_at,created_at)
);
CREATE TABLE IF NOT EXISTS rate_limits (
 bucket CHAR(64) PRIMARY KEY, hits INT UNSIGNED NOT NULL DEFAULT 0, window_start DATETIME NOT NULL
);
