<?php
// Run: php tests/run.php   (needs MySQL/MariaDB; creates and drops the database "zamhelper_test")
putenv('ZAM_DB_NAME=zamhelper_test');
$root = dirname(__DIR__); $fail = 0; $n = 0;

function t(string $name, bool $ok): void { global $fail,$n; $n++; if(!$ok){$fail++;} echo ($ok?'PASS':'FAIL')." $name\n"; }
function eq(string $name, $a, $b): void { t($name.' (got '.json_encode($a).')', $a === $b); }
$cfg = ['h'=>getenv('ZAM_DB_HOST')?:'127.0.0.1','u'=>getenv('ZAM_DB_USER')?:'root','p'=>getenv('ZAM_DB_PASS')?:''];
$adm = new PDO("mysql:host={$cfg['h']};charset=utf8mb4",$cfg['u'],$cfg['p'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
$adm->exec('DROP DATABASE IF EXISTS zamhelper_test'); $adm->exec('CREATE DATABASE zamhelper_test CHARACTER SET utf8mb4');
$sql = str_replace('USE zamhelper;','USE zamhelper_test;',preg_replace('/CREATE DATABASE[^;]*;/','',file_get_contents("$root/database.sql")));
$adm->exec($sql);
ob_start(); require "$root/includes/bootstrap.php"; ob_end_clean();
t('database connected', $pdo instanceof PDO);

/* Pure logic */
eq('access: any role may open dashboard', role_can('customer','dashboard') && role_can('admin','dashboard'), true);
eq('access: only helpers open helper workspace', [role_can('helper','helper_workspace'),role_can('admin','helper_workspace'),role_can('customer','helper_workspace')], [true,false,false]);
try { access_roles('nope'); t('access: unknown key throws', false); } catch (InvalidArgumentException $e) { t('access: unknown key throws', true); }
foreach (['dashboard.php'=>'dashboard','payments/request.php'=>'payments','helper/profile.php'=>'helper_workspace'] as $f=>$k)
  t("page $f uses access_roles('$k')", str_contains(file_get_contents("$root/$f"), "access_roles('$k')"));

/* Service catalogue: one source of truth, consistent with the database seed, icons and pages */
$cat = zam_services();
eq('catalogue has the 10 services', count($cat), 10);
foreach ($cat as $k => $sv) {
  $q = $pdo->prepare('SELECT name,base_fee,per_km_rate FROM services WHERE service_key=?'); $q->execute([$k]); $row = $q->fetch();
  eq("database seed matches catalogue: $k", $row ? [$row['name'],(float)$row['base_fee'],(float)$row['per_km_rate']] : null, [$sv['name'],(float)$sv['base'],(float)$sv['km']]);
  t("icon exists: $k", str_contains(zam_icon($k), '<svg'));
}
eq('no services in the database that the catalogue lacks', (int)$pdo->query('SELECT COUNT(*) FROM services')->fetchColumn(), count($cat));
try { zam_icon('nope'); t('icon: unknown key throws', false); } catch (InvalidArgumentException $e) { t('icon: unknown key throws', true); }
// upgrade path: old names are restored, new ones added, admin-edited fees are kept
$up = file_get_contents("$root/upgrade-existing.sql"); $blk = substr($up, strpos($up,'-- services-upsert-start'), strpos($up,'-- services-upsert-end') - strpos($up,'-- services-upsert-start'));
$pdo->exec("UPDATE services SET name='Old name' WHERE service_key='errands'"); $pdo->exec("UPDATE services SET base_fee=999 WHERE service_key='cleaning'"); $pdo->exec("DELETE FROM services WHERE service_key='tutoring'");
$pdo->exec($blk); $pdo->exec($blk);
eq('upgrade: name restored', $pdo->query("SELECT name FROM services WHERE service_key='errands'")->fetchColumn(), 'Shopping & errands');
eq('upgrade: new service added', (int)$pdo->query("SELECT COUNT(*) FROM services WHERE service_key='tutoring'")->fetchColumn(), 1);
eq('upgrade: edited fee kept', (float)$pdo->query("SELECT base_fee FROM services WHERE service_key='cleaning'")->fetchColumn(), 999.0);
$pdo->exec("UPDATE services SET base_fee=180 WHERE service_key='cleaning'");
function render(string $file, array $get = []): string { $c='$_GET='.var_export($get,true).';$_SERVER["REQUEST_METHOD"]="GET";chdir('.var_export(dirname($file),true).');include '.var_export($file,true).';'; return (string)shell_exec(escapeshellarg(PHP_BINARY).' -r '.escapeshellarg($c).' 2>&1'); }
$home = render("$root/index.php");
foreach ($cat as $k => $_) t("home page links to book.php?service=$k", str_contains($home, "book.php?service=$k"));
t('home page shows tagline and logo', str_contains($home,'Reliable Help, Anytime') && str_contains($home,'assets/zamhelper-badge'));
t('home page has no PHP warnings', !preg_match('/Warning|Notice|Fatal|Deprecated/', $home));
foreach (['laundry','delivery','tutoring','home_assistance'] as $k) { $bk = render("$root/book.php", ['service'=>$k]); t("booking form offers $k", str_contains($bk, htmlspecialchars($cat[$k]['name'], ENT_QUOTES)) && !preg_match('/Warning|Fatal/', $bk)); }
/* Brand palette contrast (WCAG AA 4.5:1 for text), read from the real stylesheet */
preg_match_all('/:root\{([^}]*)\}/', file_get_contents("$root/assets/style.css"), $m); $vars = []; foreach (explode(';', end($m[1])) as $d) if (str_contains($d,':')) { [$a,$b] = explode(':', $d, 2); $vars[trim($a)] = trim($b); }
$lum = function($hex){ $hex=ltrim($hex,'#'); $c=array_map(fn($x)=>($v=hexdec($x)/255)<=0.03928?$v/12.92:(($v+0.055)/1.055)**2.4, str_split($hex,2)); return 0.2126*$c[0]+0.7152*$c[1]+0.0722*$c[2]; };
$ratio = fn($a,$b)=>(max($lum($a),$lum($b))+0.05)/(min($lum($a),$lum($b))+0.05);
foreach ([['white on green','#ffffff',$vars['--green']],['lime on green',$vars['--lime'],$vars['--green']],['green on lime (buttons)',$vars['--green'],$vars['--lime']],['light text on card','#cfdcf5','#0f3496'],['nav text on green','#d6e2fa',$vars['--green']],['lime on step band',$vars['--lime'],$vars['--green2']],['white on step band','#e6eeff',$vars['--green2']],['dark heading on page','#1b7a34',$vars['--cream']],['body text on page',$vars['--ink'],$vars['--cream']]] as [$cn,$fg,$bg])
  t(sprintf('contrast %s >= 4.5 (got %.1f)', $cn, $ratio($fg,$bg)), $ratio($fg,$bg) >= 4.5);

/* ===================== v2 features ===================== */
function render_post(string $file, array $post, array $session = [], string $ip = '10.0.0.1'): string {
  $c='session_start();$_SESSION=array_merge($_SESSION,'.var_export($session+['csrf'=>'tok'],true).');$_POST='.var_export($post+['csrf'=>'tok'],true).';$_GET=[];$_SERVER["REQUEST_METHOD"]="POST";$_SERVER["REMOTE_ADDR"]='.var_export($ip,true).';chdir('.var_export(dirname($file),true).');include '.var_export($file,true).';';
  return (string)shell_exec(escapeshellarg(PHP_BINARY).' -d session.save_path=/tmp -r '.escapeshellarg($c).' 2>&1');
}
function render_get(string $file, array $get, array $session = [], string $ip = '10.0.0.2'): string {
  $c='session_start();$_SESSION=array_merge($_SESSION,'.var_export($session,true).');$_GET='.var_export($get,true).';$_SERVER["REQUEST_METHOD"]="GET";$_SERVER["REMOTE_ADDR"]='.var_export($ip,true).';chdir('.var_export(dirname($file),true).');include '.var_export($file,true).';';
  return (string)shell_exec(escapeshellarg(PHP_BINARY).' -d session.save_path=/tmp -r '.escapeshellarg($c).' 2>&1');
}
$tz = zam_tz(); $nowL = zam_now();

/* scheduling rules */
eq('slot parse: valid', zam_parse_slot('2030-05-17T10:30')?->format('Y-m-d H:i'), '2030-05-17 10:30');
eq('slot parse: rejects 31 Feb', zam_parse_slot('2030-02-31T10:00'), null); eq('slot parse: rejects junk', zam_parse_slot('tomorrow'), null);
$fixedNow = new DateTimeImmutable('2030-05-17 09:00', $tz);
eq('slot: 30 min notice rejected', count(zam_slot_errors(new DateTimeImmutable('2030-05-17 09:30', $tz), $fixedNow)) > 0, true);
eq('slot: 2 hours ahead accepted', zam_slot_errors(new DateTimeImmutable('2030-05-17 11:00', $tz), $fixedNow), []);
eq('slot: 05:00 rejected (before opening)', count(zam_slot_errors(new DateTimeImmutable('2030-05-18 05:00', $tz), $fixedNow)) > 0, true);
eq('slot: 21:00 rejected (after last start)', count(zam_slot_errors(new DateTimeImmutable('2030-05-18 21:00', $tz), $fixedNow)) > 0, true);
eq('slot: 20:45 accepted', zam_slot_errors(new DateTimeImmutable('2030-05-18 20:45', $tz), $fixedNow), []);
eq('slot: 100 days ahead rejected', count(zam_slot_errors(new DateTimeImmutable('2030-08-30 10:00', $tz), $fixedNow)) > 0, true);
eq('overlap: back-to-back does not overlap', zam_windows_overlap('2030-01-01 10:00:00','2030-01-01 12:00:00','2030-01-01 12:00:00','2030-01-01 14:00:00'), false);
eq('overlap: partial overlap', zam_windows_overlap('2030-01-01 10:00:00','2030-01-01 12:00:00','2030-01-01 11:00:00','2030-01-01 13:00:00'), true);
eq('overlap: open-ended blocks later work', zam_windows_overlap('2030-01-01 10:00:00',null,'2030-02-01 10:00:00','2030-02-01 12:00:00'), true);

/* pricing and geo */
eq('price: base + travel, no urgency', zam_price(100, 8, 10, false)['total'], 180.0);
eq('price: urgent adds 25%', zam_price(100, 8, 10, true)['total'], 225.0);
eq('price: distance clamped to 500 km', zam_price(100, 8, 9999, false)['distance_km'], 500.0);
$d = zam_haversine_km(-15.4167, 28.2833, -12.9587, 28.6366); t("geo: Lusaka to Ndola is about 270 km straight-line (got ".round($d).")", $d > 255 && $d < 295);
eq('geo: same point is 0 km', zam_road_km(-15.4, 28.3, -15.4, 28.3), 0.0);
eq('geo: coordinates inside Zambia accepted', zam_coords_ok(-15.4, 28.3), true);
eq('geo: coordinates in London rejected', zam_coords_ok(51.5, -0.12), false); eq('geo: junk rejected', zam_coords_ok('abc', '1'), false);
eq('geo: city centre lookup is case-insensitive', zam_city_centre(' LUSAKA ')[0], 'Lusaka');

/* fixtures: customer, helper user + helper (verified, offers cleaning) */
$pdo->exec("INSERT INTO users(name,email,phone,password_hash,role) VALUES ('Chanda Mwila','chanda@example.com','0971000001','x','customer'),('Bupe Banda',NULL,'0971000002','x','helper'),('Other Person',NULL,'0971000003','x','customer')");
$cust = (int)$pdo->query("SELECT id FROM users WHERE phone='0971000001'")->fetchColumn(); $hUser = (int)$pdo->query("SELECT id FROM users WHERE phone='0971000002'")->fetchColumn(); $other = (int)$pdo->query("SELECT id FROM users WHERE phone='0971000003'")->fetchColumn();
$pdo->exec("INSERT INTO helpers(user_id,name,phone,city,skills,is_verified,verification_status,is_available) VALUES ($hUser,'Bupe Banda','0971000002','Lusaka','Cleaning and laundry',1,'verified',1)");
$hid = (int)$pdo->lastInsertId(); $pdo->exec("INSERT INTO helper_services(helper_id,service_id) SELECT $hid,id FROM services WHERE service_key IN ('cleaning','laundry')");
$day = $nowL->modify('+3 days')->format('Y-m-d'); $slot = fn($hm) => $day.'T'.$hm;
$bookingPost = fn(array $o = []) => $o + ['service'=>'cleaning','name'=>'Test Customer','phone'=>'0970000000','city'=>'Lusaka','area'=>'Kabulonga','details'=>'Please clean','distance_km'=>'0','when_mode'=>'asap','duration'=>'120','helper_id'=>'0'];
$count = fn(string $w='1=1') => (int)$pdo->query("SELECT COUNT(*) FROM bookings WHERE $w")->fetchColumn(); $ip = 20;

/* booking: as-soon-as-possible (no helper) */
$o = render_post("$root/book.php", $bookingPost(), [], '10.1.0.'.$ip++);
t('booking ASAP: success page and no PHP errors', str_contains($o,'REQUEST PREPARED') && !preg_match('/Warning|Fatal|Notice/', $o));
$row = $pdo->query("SELECT * FROM bookings ORDER BY id DESC LIMIT 1")->fetch();
eq('booking ASAP: stored without a scheduled time', [$row['scheduled_start'], (int)$row['duration_minutes']], [null, 120]);
t('booking ASAP: created_at written in Lusaka time', abs(strtotime($row['created_at']) - strtotime(zam_db_time(zam_now()))) < 120);

/* booking: scheduled with a chosen helper, then overlap protection */
$o = render_post("$root/book.php", $bookingPost(['when_mode'=>'scheduled','when'=>$slot('10:00'),'duration'=>'120','helper_id'=>(string)$hid]), [], '10.1.0.'.$ip++);
t('booking scheduled with helper: success', str_contains($o,'REQUEST PREPARED'));
$row = $pdo->query("SELECT * FROM bookings ORDER BY id DESC LIMIT 1")->fetch();
eq('booking scheduled: start, duration and helper stored', [$row['scheduled_start'], (int)$row['duration_minutes'], (int)$row['helper_id']], ["$day 10:00:00", 120, $hid]);
$before = $count();
$o = render_post("$root/book.php", $bookingPost(['when_mode'=>'scheduled','when'=>$slot('11:00'),'helper_id'=>(string)$hid]), [], '10.1.0.'.$ip++);
t('booking overlap (11:00 inside 10:00-12:00) is refused', str_contains($o,'already booked') && $count() === $before);
$o = render_post("$root/book.php", $bookingPost(['when_mode'=>'scheduled','when'=>$slot('12:00'),'helper_id'=>(string)$hid]), [], '10.1.0.'.$ip++);
t('booking back-to-back (12:00) is accepted', str_contains($o,'REQUEST PREPARED') && $count() === $before + 1);
$o = render_post("$root/book.php", $bookingPost(['when_mode'=>'scheduled','when'=>$nowL->modify('+4 days')->format('Y-m-d').'T10:00','helper_id'=>(string)$hid]), [], '10.1.0.'.$ip++);
t('same helper on another day is accepted', str_contains($o,'REQUEST PREPARED'));
$before = $count(); $o = render_post("$root/book.php", $bookingPost(['when_mode'=>'scheduled','when'=>$nowL->modify('-1 day')->format('Y-m-d').'T10:00']), [], '10.1.0.'.$ip++);
t('booking in the past is refused', !str_contains($o,'REQUEST PREPARED') && $count() === $before);
$o = render_post("$root/book.php", $bookingPost(['when_mode'=>'scheduled','when'=>$slot('03:00')]), [], '10.1.0.'.$ip++);
t('booking at 03:00 is refused (outside hours)', !str_contains($o,'REQUEST PREPARED') && str_contains($o,'Start times are between'));
$o = render_post("$root/book.php", $bookingPost(['duration'=>'999']), [], '10.1.0.'.$ip++); t('booking with invalid duration is refused', !str_contains($o,'REQUEST PREPARED'));

/* booking: map pin sets the distance on the server (client value is ignored) */
$o = render_post("$root/book.php", $bookingPost(['service'=>'delivery','city'=>'Lusaka','job_lat'=>'-15.3875','job_lng'=>'28.3228','distance_km'=>'0']), [], '10.1.0.'.$ip++);
$row = $pdo->query("SELECT * FROM bookings ORDER BY id DESC LIMIT 1")->fetch();
t('booking with pin: success, pin stored, distance computed server-side', str_contains($o,'REQUEST PREPARED') && (float)$row['job_lat'] === -15.3875 && (float)$row['distance_km'] > 0, true);
eq('booking with pin: fee = base + travel from computed distance', (float)$row['estimated_fee'], zam_price(100, 8, (float)$row['distance_km'], false)['total']);
$before = $count(); $o = render_post("$root/book.php", $bookingPost(['job_lat'=>'51.5','job_lng'=>'-0.12']), [], '10.1.0.'.$ip++);
t('booking with a pin outside Zambia is refused', str_contains($o,'inside Zambia') && $count() === $before);
$bk = render("$root/book.php"); t('booking page offers scheduling, map and live price hooks', str_contains($bk,'when_mode') && str_contains($bk,'id="pinMap"') && str_contains($bk,'assets/book.js') && str_contains($bk,'assets/vendor/leaflet/leaflet.js') && !preg_match('/Warning|Fatal/', $bk));

/* conflict query vs PHP map agree (admin dropdown) */
$ws = "$day 11:00:00"; $we = "$day 12:00:00";
eq('conflict query: busy at 11:00', zam_helper_conflict($pdo, $hid, $ws, $we), true);
eq('conflict query: free at 15:00', zam_helper_conflict($pdo, $hid, "$day 15:00:00", "$day 16:00:00"), false);
$bm = zam_busy_map($pdo); eq('busy map agrees with query (11:00)', zam_busy_conflict($bm, $hid, $ws, $we), true); eq('busy map agrees with query (15:00)', zam_busy_conflict($bm, $hid, "$day 15:00:00", "$day 16:00:00"), false);
$bid = (int)$pdo->query("SELECT id FROM bookings WHERE helper_id=$hid AND scheduled_start='$day 10:00:00'")->fetchColumn();
eq('conflict query: a booking does not conflict with itself', zam_helper_conflict($pdo, $hid, "$day 10:00:00", "$day 12:00:00", $bid), false);
$pdo->exec("UPDATE bookings SET status='cancelled' WHERE id=$bid"); eq('cancelled booking frees the slot', zam_helper_conflict($pdo, $hid, $ws, $we), false);

/* helper list */
$lst = zam_list_helpers($pdo); eq('helper list: one verified helper', [$lst['total'], $lst['items'][0]['name']], [1, 'Bupe Banda']);
eq('helper list: filter by service', zam_list_helpers($pdo, '', 'laundry')['total'], 1); eq('helper list: filter by a service they do not offer', zam_list_helpers($pdo, '', 'tutoring')['total'], 0);
eq('helper list: text search miss', zam_list_helpers($pdo, 'zzz')['total'], 0);
eq('helper list: not busy right now', (int)$lst['items'][0]['busy_now'], 0);
$pdo->exec("INSERT INTO bookings(booking_code,helper_id,customer_name,phone,city,service_key,status,created_at) VALUES ('ZH-BUSY01-1',$hid,'x','0970000000','Lusaka','cleaning','confirmed','".zam_db_time(zam_now()->modify('-10 minutes'))."')");
eq('helper list: open-ended ASAP job marks helper busy now', (int)zam_list_helpers($pdo)['items'][0]['busy_now'], 1);
$pdo->exec("UPDATE bookings SET status='completed' WHERE booking_code='ZH-BUSY01-1'");

/* JSON API */
$j = json_decode(render("$root/api/price.php", ['service'=>'errands','distance_km'=>'10','urgent'=>'1']), true);
eq('api/price: errands 10 km urgent', [(float)($j['total'] ?? 0), $j['distance_source'] ?? null], [225.0, 'typed']);
$j = json_decode(render("$root/api/price.php", ['service'=>'errands','lat'=>'-15.3875','lng'=>'28.3228','city'=>'Lusaka']), true);
eq('api/price: map pin computes distance', [$j['distance_source'] ?? null, ($j['distance_km'] ?? 0) > 0], ['map_pin', true]);
eq('api/price: unknown service is a 400 error', json_decode(render("$root/api/price.php", ['service'=>'nope']), true)['error'] ?? null, 'unknown_service');
$j = json_decode(render("$root/api/helpers.php", ['q'=>'bupe']), true); eq('api/helpers: search returns the helper', [$j['total'] ?? null, $j['items'][0]['name'] ?? null, $j['items'][0]['profile_url'] ?? null], [1, 'Bupe Banda', "helper-view.php?id=$hid"]);
$j = json_decode(render("$root/api/availability.php", ['helper'=>(string)$hid,'service'=>'cleaning','when'=>$slot('10:00'),'duration'=>'120']), true); eq('api/availability: free after cancellation', $j['available'] ?? null, true);
$j = json_decode(render("$root/api/availability.php", ['helper'=>(string)$hid,'service'=>'tutoring']), true); eq('api/availability: service not offered', $j['available'] ?? null, false);
eq('api/notifications: signed-out is 401', json_decode(render("$root/api/notifications.php", []), true)['error'] ?? null, 'not_signed_in');
t('helpers page renders cards without PHP errors', ($hp = render("$root/helpers.php")) && str_contains($hp,'Bupe Banda') && str_contains($hp,'helper-view.php?id='.$hid) && !preg_match('/Warning|Fatal|Notice/', $hp));

/* reviews */
$pdo->exec("INSERT INTO bookings(booking_code,customer_user_id,helper_id,customer_name,phone,city,service_key,status,created_at) VALUES ('ZH-REVW01-1',$cust,$hid,'Chanda','0971000001','Lusaka','cleaning','completed','".zam_db_time(zam_now())."'),('ZH-REVW02-2',$cust,$hid,'Chanda','0971000001','Lusaka','cleaning','confirmed','".zam_db_time(zam_now())."')");
$rb = (int)$pdo->query("SELECT id FROM bookings WHERE booking_code='ZH-REVW01-1'")->fetchColumn(); $rb2 = (int)$pdo->query("SELECT id FROM bookings WHERE booking_code='ZH-REVW02-2'")->fetchColumn();
eq('review: completed own booking is reviewable', zam_reviewable_booking($pdo, $rb, $cust)[1], null);
t('review: someone else cannot review it', zam_reviewable_booking($pdo, $rb, $other)[1] !== null);
t('review: unfinished booking cannot be reviewed', str_contains((string)zam_reviewable_booking($pdo, $rb2, $cust)[1], 'completed'));
$o = render_post("$root/review.php", ['booking_id'=>(string)$rb,'rating'=>'4','comment'=>'Great work'], ['user_id'=>$cust], '10.2.0.1');
t('review: submit succeeds', str_contains($o,'Thank you!') && !preg_match('/Warning|Fatal/', $o));
$hrow = $pdo->query("SELECT rating,review_count FROM helpers WHERE id=$hid")->fetch(); eq('review: helper rating and count updated', [(float)$hrow['rating'], (int)$hrow['review_count']], [4.0, 1]);
eq('review: helper was notified', (int)$pdo->query("SELECT COUNT(*) FROM notifications WHERE user_id=$hUser AND event='review_received'")->fetchColumn(), 1);
$o = render_post("$root/review.php", ['booking_id'=>(string)$rb,'rating'=>'1'], ['user_id'=>$cust], '10.2.0.2'); t('review: second review for same booking refused', str_contains($o,'already reviewed') && (int)$pdo->query('SELECT COUNT(*) FROM reviews')->fetchColumn() === 1);
$o = render_post("$root/review.php", ['booking_id'=>(string)$rb,'rating'=>'5'], ['user_id'=>$other], '10.2.0.3'); t('review: other customer refused', !str_contains($o,'Thank you!'));
$pdo->exec("UPDATE bookings SET status='completed' WHERE id=$rb2"); $o = render_post("$root/review.php", ['booking_id'=>(string)$rb2,'rating'=>'9'], ['user_id'=>$cust], '10.2.0.4'); t('review: rating 9 refused', str_contains($o,'1 to 5 stars'));
$pdo->prepare('INSERT INTO reviews(booking_id,helper_id,customer_user_id,rating,comment,created_at) VALUES (?,?,?,?,?,?)')->execute([$rb2,$hid,$cust,2,'',zam_db_time(zam_now())]); zam_recalc_helper_rating($pdo, $hid);
eq('review: average of 4 and 2 is 3.0', (float)$pdo->query("SELECT rating FROM helpers WHERE id=$hid")->fetchColumn(), 3.0);
$pdo->exec("UPDATE reviews SET is_hidden=1 WHERE booking_id=$rb2"); zam_recalc_helper_rating($pdo, $hid); eq('review: hidden review stops counting', (float)$pdo->query("SELECT rating FROM helpers WHERE id=$hid")->fetchColumn(), 4.0);
try { $pdo->exec("INSERT INTO reviews(booking_id,helper_id,customer_user_id,rating,created_at) VALUES ($rb,$hid,$cust,3,NOW())"); t('review: database allows only one per booking', false); } catch (Throwable $e) { t('review: database allows only one per booking', true); }
$pv = render_get("$root/helper-view.php", ['id'=>(string)$hid]); t('helper profile page shows the review with first name + initial', str_contains($pv,'Great work') && str_contains($pv,'Chanda M.') && !str_contains($pv,'0971000001'));
eq('helper profile: unknown helper is a 404 page', str_contains(render_get("$root/helper-view.php", ['id'=>'99999']), 'Helper not found'), true);

/* notifications */
eq('wa number: 097... -> 26097...', zam_wa_number('0971 234 567'), '260971234567'); eq('wa number: +260 kept', zam_wa_number('+260 971 234 567'), '260971234567');
eq('status message: completed asks for a rating', str_contains((string)zam_status_message('completed','ZH-X'), 'rate'), true); eq('status message: pending has none', zam_status_message('pending','ZH-X'), null);
$bkRow = $pdo->query("SELECT id,booking_code,customer_user_id,helper_id FROM bookings WHERE id=$rb")->fetch();
zam_notify_booking($bkRow, 'status', 'completed'); eq('notify: customer gets a completed message with a review link', $pdo->query("SELECT link FROM notifications WHERE user_id=$cust AND event='status_completed'")->fetchColumn(), "review.php?booking=$rb");
zam_notify_booking($bkRow, 'assigned'); eq('notify: assignment notifies customer and helper', [(int)$pdo->query("SELECT COUNT(*) FROM notifications WHERE user_id=$cust AND event='assigned'")->fetchColumn(), (int)$pdo->query("SELECT COUNT(*) FROM notifications WHERE user_id=$hUser AND event='job_assigned'")->fetchColumn()], [1, 1]);
$j = json_decode(render_get("$root/api/notifications.php", [], ['user_id'=>$cust]), true); t('api/notifications: signed-in user sees own unread items', ($j['unread'] ?? 0) >= 2 && isset($j['items'][0]['message']));
$np = render_get("$root/notifications.php", [], ['user_id'=>$cust]); t('notifications page lists messages', str_contains($np,'is confirmed') === false && str_contains($np,'complete') && !preg_match('/Warning|Fatal/', $np));
t('notifications: other users cannot see them', !str_contains(render_get("$root/notifications.php", [], ['user_id'=>$other]), 'Please rate your helper'));
eq('mail: disabled without ZAM_MAIL_FROM', zam_mail('a@b.co','s','b'), false);

/* rate limiting (database-backed, per IP / subject) */
$_SERVER['REMOTE_ADDR'] = '203.0.113.7';
eq('throttle: first 3 hits pass', [throttle('t1',3,60), throttle('t1',3,60), throttle('t1',3,60)], [true,true,true]); eq('throttle: 4th hit blocked', throttle('t1',3,60), false);
$_SERVER['REMOTE_ADDR'] = '203.0.113.8'; eq('throttle: another IP is independent', throttle('t1',3,60), true);
eq('throttle: subject-keyed limit (same subject blocked across IPs)', [throttle('t2',1,60,'amy'), throttle('t2',1,60,'amy'), throttle('t2',1,60,'bob')], [true,false,true]);
$pdo->exec("UPDATE rate_limits SET window_start = NOW() - INTERVAL 2 HOUR"); eq('throttle: window expires and resets', throttle('t1',3,60), true);
$o = ''; for ($i = 0; $i < 12; $i++) $o = render_post("$root/book.php", $bookingPost(), [], '198.51.100.9'); t('booking form is rate limited per IP (429 after 10/hour)', str_contains($o,'Too many requests'));
for ($i = 0; $i < 9; $i++) $o = render_post("$root/auth/login.php", ['identifier'=>'nobody@example.com','password'=>'wrong'], [], '198.51.100.10'); t('login is rate limited per IP', str_contains($o,'Too many sign-in attempts'));
for ($i = 0; $i < 7; $i++) $o = render_post("$root/auth/login.php", ['identifier'=>'victim@example.com','password'=>'wrong'], [], '198.51.100.'.(30+$i)); t('login is rate limited per account across IPs', str_contains($o,'Too many sign-in attempts'));
for ($i = 0; $i < 200; $i++) { if (!throttle('api:price',180,60)) break; } $_SERVER['REMOTE_ADDR'] = '203.0.113.99'; for ($i = 0; $i < 181; $i++) $ok = throttle('api:price',180,60); eq('api guard bucket blocks after its limit', $ok, false);

/* payment webhook (signed, idempotent) */
$pdo->exec("INSERT INTO bookings(booking_code,customer_user_id,customer_name,phone,city,service_key,estimated_fee,status,payment_status,created_at) VALUES ('ZH-PAYW01-1',$cust,'Chanda','0971000001','Lusaka','cleaning',250,'confirmed','pending','".zam_db_time(zam_now())."')"); $pb = (int)$pdo->lastInsertId();
$pdo->exec("INSERT INTO payment_enquiries(booking_id,customer_user_id,booking_code,amount,payer_phone,status) VALUES ($pb,$cust,'ZH-PAYW01-1',250,'0971000001','requested')"); $pe = (int)$pdo->lastInsertId();
require_once "$root/includes/payments.php"; $sec = 'test-secret-123'; $nowTs = 1800000000;
$mk = fn(array $o = []) => json_encode($o + ['event'=>'payment.succeeded','reference'=>"ZHPE-$pe",'amount'=>250.0,'provider_ref'=>'TXN-1','timestamp'=>$nowTs]);
$sig = fn(string $body, string $s = 'test-secret-123') => 'sha256=' . hash_hmac('sha256', $body, $s);
eq('webhook: disabled without a secret', zam_process_payment_webhook($pdo, $mk(), $sig($mk()), '', $nowTs)[0], 503);
eq('webhook: wrong signature rejected', zam_process_payment_webhook($pdo, $mk(), $sig($mk(), 'other'), $sec, $nowTs)[0], 401);
eq('webhook: missing signature rejected', zam_process_payment_webhook($pdo, $mk(), '', $sec, $nowTs)[0], 401);
eq('webhook: tampered body rejected', zam_process_payment_webhook($pdo, $mk(['amount'=>1.0]), $sig($mk()), $sec, $nowTs)[0], 401);
eq('webhook: stale timestamp rejected', zam_process_payment_webhook($pdo, $mk(), $sig($mk()), $sec, $nowTs + 4000)[0], 400);
$b2 = $mk(['amount'=>100.0]); eq('webhook: amount below the enquiry rejected', zam_process_payment_webhook($pdo, $b2, $sig($b2), $sec, $nowTs)[0], 409);
$b3 = $mk(['reference'=>'ZHPE-99999']); eq('webhook: unknown enquiry is 404', zam_process_payment_webhook($pdo, $b3, $sig($b3), $sec, $nowTs)[0], 404);
$b4 = $mk(['event'=>'refund']); eq('webhook: unsupported event rejected', zam_process_payment_webhook($pdo, $b4, $sig($b4), $sec, $nowTs)[0], 400);
[$c1, $r1] = zam_process_payment_webhook($pdo, $mk(), $sig($mk()), $sec, $nowTs); eq('webhook: valid event marks paid', [$c1, $r1['status']], [200, 'paid']);
eq('webhook: enquiry and booking updated', [$pdo->query("SELECT status FROM payment_enquiries WHERE id=$pe")->fetchColumn(), $pdo->query("SELECT payment_status FROM bookings WHERE id=$pb")->fetchColumn(), $pdo->query("SELECT verified_reference FROM payment_enquiries WHERE id=$pe")->fetchColumn()], ['paid','paid','webhook:TXN-1']);
eq('webhook: replay is idempotent', zam_process_payment_webhook($pdo, $mk(), $sig($mk()), $sec, $nowTs)[1]['status'], 'already_processed');
eq('webhook: customer notified once', (int)$pdo->query("SELECT COUNT(*) FROM notifications WHERE user_id=$cust AND event='payment_paid'")->fetchColumn(), 1);

/* photo upload (GD) */
if (function_exists('imagecreatetruecolor')) {
  $tmp = tempnam(sys_get_temp_dir(), 'ph'); $im = imagecreatetruecolor(800, 500); imagefill($im, 0, 0, imagecolorallocate($im, 30, 90, 200)); imagejpeg($im, $tmp, 90);
  $junk = file_get_contents($tmp) . '<?php echo "pwn"; ?>'; file_put_contents($tmp, $junk); // trailing payload must not survive re-encoding
  [$name, $err] = zam_save_helper_photo(['error'=>UPLOAD_ERR_OK,'size'=>filesize($tmp),'tmp_name'=>$tmp,'name'=>'me.jpg'], $hid); t('photo: valid JPEG accepted', $name !== null && $err === null);
  $saved = zam_photo_dir().'/'.$name; $sz = @getimagesize($saved); eq('photo: re-encoded to a 480x480 square JPEG', [$sz[0] ?? 0, $sz[1] ?? 0, $sz['mime'] ?? ''], [480, 480, 'image/jpeg']);
  t('photo: hidden payload stripped by re-encoding', is_file($saved) && !str_contains(file_get_contents($saved), '<?php'));
  eq('photo: url helper only accepts safe names', [zam_photo_url($name), zam_photo_url('../../etc/passwd'), zam_photo_url('x.php')], ["uploads/helpers/$name", null, null]);
  [$n2, $e2] = zam_save_helper_photo(['error'=>UPLOAD_ERR_OK,'size'=>filesize($tmp),'tmp_name'=>$tmp,'name'=>'me.jpg'], $hid, $name); t('photo: replacing deletes the old file', $n2 !== null && !is_file($saved) && is_file(zam_photo_dir().'/'.$n2));
  zam_delete_helper_photo($n2); eq('photo: delete removes the file', is_file(zam_photo_dir().'/'.$n2), false);
  $txt = tempnam(sys_get_temp_dir(), 'tx'); file_put_contents($txt, '<?php phpinfo();'); [$n3, $e3] = zam_save_helper_photo(['error'=>UPLOAD_ERR_OK,'size'=>20,'tmp_name'=>$txt,'name'=>'x.jpg'], $hid); t('photo: PHP file renamed .jpg is rejected', $n3 === null && str_contains((string)$e3, 'Only JPG'));
  [$n4, $e4] = zam_save_helper_photo(['error'=>UPLOAD_ERR_OK,'size'=>9*1024*1024,'tmp_name'=>$tmp,'name'=>'big.jpg'], $hid); t('photo: oversize rejected', $n4 === null && str_contains((string)$e4, '3 MB'));
  unlink($tmp); unlink($txt);
} else { echo "SKIP photo tests (GD not installed)\n"; }

/* PWA */
$man = json_decode(file_get_contents("$root/manifest.webmanifest"), true);
t('manifest: name, start_url, standalone, theme colour', ($man['name'] ?? '') === 'ZamHelper' && ($man['display'] ?? '') === 'standalone' && !empty($man['start_url']) && preg_match('/^#[0-9a-f]{6}$/i', $man['theme_color'] ?? ''));
foreach ($man['icons'] ?? [] as $ic) { $p = "$root/{$ic['src']}"; $isz = @getimagesize($p); t("manifest icon {$ic['src']} exists at {$ic['sizes']}", $isz && "{$isz[0]}x{$isz[1]}" === $ic['sizes']); }
t('manifest has a maskable icon', in_array('maskable', array_column($man['icons'] ?? [], 'purpose'), true));
$sw = file_get_contents("$root/sw.js"); t('service worker: skips api/auth/admin/payments and non-GET', str_contains($sw, 'api|auth|admin|payments') && str_contains($sw, "req.method !== 'GET'"));
t('service worker: never caches page navigations', str_contains($sw, "req.mode === 'navigate'") && str_contains($sw, 'offline.html') && !preg_match('/cache\.put\(req.*navigate/s', $sw));
foreach (['offline.html','assets/vendor/leaflet/leaflet.js','assets/vendor/leaflet/leaflet.css','assets/vendor/leaflet/images/marker-icon.png'] as $f) t("file exists: $f", is_file("$root/$f"));
foreach (preg_grep('/^[a-z0-9\/._-]+$/', array_map(fn($m) => trim($m, "'"), preg_split('/,\s*/', trim(explode(']', explode('PRECACHE = [', $sw)[1])[0])))) as $f) t("service worker precache file exists: $f", is_file("$root/$f"));
$home = render("$root/index.php"); t('pages link the manifest, icons and register-ready script', str_contains($home,'manifest.webmanifest') && str_contains($home,'apple-touch-icon') && str_contains($home,'ZAM_BASE'));
t('uploads folder blocks script execution', str_contains(file_get_contents("$root/uploads/.htaccess"), 'Require all denied'));

/* schema + upgrade script stay in sync */
$up2 = file_get_contents("$root/upgrade-v2.sql"); foreach (['review_count','photo_path','base_lat','scheduled_start','duration_minutes','job_lat','reviews','notifications','rate_limits'] as $w) t("upgrade-v2.sql covers $w", str_contains($up2, $w));
$adm->exec('DROP DATABASE zamhelper_test');
echo "\n$n tests, $fail failed\n"; exit($fail?1:0);
