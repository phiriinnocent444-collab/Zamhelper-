<?php
require __DIR__.'/../includes/bootstrap.php';
$u = require_login(access_roles('payments'));
$pageTitle = 'WhatsApp payment enquiry';
$basePath = '../';
$errors = []; $booking = null; $wa = ''; $enquiryId = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    throttle_or_die('payment_enquiry', 10, 3600);
    csrf_check();
    $ref = strtoupper(trim((string)($_POST['booking_code'] ?? '')));
    $phone = trim((string)($_POST['payer_phone'] ?? $u['phone']));
    if (!valid_phone($phone)) $errors[] = 'Enter a valid contact phone number.';
    if (!$pdo) $errors[] = 'Database is unavailable. Please try again later.';
    if (!$errors) {
        $q = $pdo->prepare('SELECT b.*, s.name AS service_name FROM bookings b LEFT JOIN services s ON s.service_key=b.service_key WHERE b.booking_code=? AND b.customer_user_id=? LIMIT 1');
        $q->execute([$ref, $u['id']]); $booking = $q->fetch();
        if (!$booking) $errors[] = 'Booking not found for your signed-in account.';
        elseif (!in_array($booking['status'], ['confirmed','in_progress','completed'], true)) $errors[] = 'Please wait until your booking is confirmed before requesting payment instructions.';
        elseif ($booking['payment_status'] === 'paid') $errors[] = 'This booking is already marked as paid.';
        else {
            try {
                $q = $pdo->prepare("INSERT INTO payment_enquiries (booking_id, customer_user_id, booking_code, amount, payer_phone, status) VALUES (?,?,?,?,?,'requested')");
                $q->execute([$booking['id'], $u['id'], $booking['booking_code'], $booking['estimated_fee'], $phone]);
                $enquiryId = (int)$pdo->lastInsertId();
                $pdo->prepare("UPDATE bookings SET payment_status='pending' WHERE id=?")->execute([$booking['id']]);
                audit_log($u['id'], 'whatsapp_payment_enquiry_created', 'payment_enquiry', $enquiryId, ['booking' => $booking['booking_code']]);
                $service = $booking['service_name'] ?: ucwords(str_replace('_',' ',$booking['service_key']));
                $message = "ZAMHELPER PAYMENT ENQUIRY\nEnquiry: ZHPE-{$enquiryId}\nBooking: {$booking['booking_code']}\nService: {$service}\nIndicative amount: ".money($booking['estimated_fee'])."\nCustomer: {$u['name']}\nContact phone: {$phone}\n\nPlease confirm the final amount and provide official payment instructions. I will never share a mobile-money PIN or OTP.";
                $wa = wa_link($message, '260772300053');
            } catch (Throwable $e) { $errors[] = 'Could not save the enquiry. Check the database setup and try again.'; }
        }
    }
}
require __DIR__.'/../includes/header.php';
?>
<section class="page-hero"><div class="eyebrow">WHATSAPP PAYMENT ENQUIRY</div><h1>Arrange payment, <span class="lime">with a real person.</span></h1><p>All ZamHelper payment enquiries go through WhatsApp at +260 772 300 053. No Airtel or MTN gateway is connected to this website.</p></section>
<section class="section apply-section"><div class="apply-card">
<?php if ($enquiryId && $wa): ?>
<h2>Enquiry prepared</h2><p>Your enquiry reference is <b>ZHPE-<?=intval($enquiryId)?></b>. Booking <b><?=e($booking['booking_code'])?></b> · indicative amount <b><?=money($booking['estimated_fee'])?></b>.</p>
<div class="notice"><b>Before you continue</b><p>Review the pre-filled WhatsApp message and tap Send. The amount is an estimate until ZamHelper confirms the final quote. Your booking is not proof of payment. Never share a PIN, password or OTP.</p></div>
<a class="btn btn-primary btn-full" target="_blank" rel="noopener noreferrer" href="<?=e($wa)?>">Continue to WhatsApp ↗</a>
<?php else: ?>
<?php if ($errors): ?><div class="form-errors"><ul><?php foreach($errors as $error): ?><li><?=e($error)?></li><?php endforeach ?></ul></div><?php endif ?>
<form method="post" class="booking-form"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><label>Booking reference<input name="booking_code" required maxlength="32" placeholder="ZH-ABC123-4" value="<?=e($_POST['booking_code']??'')?>"></label><label>Your contact phone number<input name="payer_phone" required maxlength="24" value="<?=e($_POST['payer_phone']??$u['phone'])?>"></label><button class="btn btn-primary btn-full">Prepare WhatsApp payment enquiry</button></form>
<?php endif ?>
</div></section>
<?php require __DIR__.'/../includes/footer.php'; ?>
