<?php
require __DIR__ . '/../includes/bootstrap.php'; require_once __DIR__ . '/../includes/payments.php';
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { header('Allow: POST'); api_json(['error' => 'method_not_allowed'], 405); }
api_guard('webhook', 120, 60);
if (!$pdo) api_json(['error' => 'database_unavailable'], 503);
$raw = file_get_contents('php://input', false, null, 0, 65537);
if ($raw === false || strlen($raw) > 65536) api_json(['error' => 'payload_too_large'], 413);
[$code, $body] = zam_process_payment_webhook($pdo, $raw, (string)($_SERVER['HTTP_X_ZAM_SIGNATURE'] ?? ''), (string)(getenv('ZAM_PAYMENT_WEBHOOK_SECRET') ?: ''));
api_json($body, $code);
