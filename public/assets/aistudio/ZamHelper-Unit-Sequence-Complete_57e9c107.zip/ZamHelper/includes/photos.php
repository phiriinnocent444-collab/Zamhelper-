<?php
/**
 * Helper profile photos. The upload is never stored as-is: it is decoded with GD, rotated by its EXIF orientation,
 * centre-cropped to a square, resized and re-encoded as a JPEG. That strips EXIF/GPS data and any hidden payload.
 */
const ZAM_PHOTO_MAX_BYTES = 3 * 1024 * 1024;
const ZAM_PHOTO_SIZE = 480;
function zam_photo_dir(): string { return __DIR__ . '/../uploads/helpers'; }
function zam_photo_url(?string $file, string $base = ''): ?string { return ($file && preg_match('/^[a-z0-9-]+\.jpg$/', $file)) ? $base . 'uploads/helpers/' . $file : null; }
/** @return array{0:?string,1:?string} [stored filename, error message] */
function zam_save_helper_photo(array $f, int $helperId, ?string $oldFile = null): array {
  if (!function_exists('imagecreatefromstring') || !function_exists('imagejpeg')) return [null, 'Photo uploads need the PHP GD extension (enable extension=gd in php.ini).'];
  if (($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) return [null, 'Choose a photo to upload.'];
  if (($f['size'] ?? 0) > ZAM_PHOTO_MAX_BYTES) return [null, 'Maximum photo size is 3 MB.'];
  $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
  if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp'], true)) return [null, 'Only JPG, PNG and WebP photos are accepted.'];
  $info = @getimagesize($f['tmp_name']);
  if (!$info || $info[0] < 100 || $info[1] < 100 || $info[0] > 8000 || $info[1] > 8000) return [null, 'The photo must be between 100 and 8000 pixels wide and tall.'];
  $img = @imagecreatefromstring((string)file_get_contents($f['tmp_name']));
  if (!$img) return [null, 'That image could not be read.'];
  if ($mime === 'image/jpeg' && function_exists('exif_read_data') && function_exists('imagerotate')) {
    $ex = @exif_read_data($f['tmp_name']); $o = $ex['Orientation'] ?? 1;
    $deg = [3 => 180, 6 => -90, 8 => 90][$o] ?? 0; if ($deg) { $r = imagerotate($img, $deg, 0); if ($r) { imagedestroy($img); $img = $r; } }
  }
  $w = imagesx($img); $h = imagesy($img); $side = min($w, $h);
  $out = imagecreatetruecolor(ZAM_PHOTO_SIZE, ZAM_PHOTO_SIZE); imagefill($out, 0, 0, imagecolorallocate($out, 255, 255, 255));
  imagecopyresampled($out, $img, 0, 0, intdiv($w - $side, 2), intdiv($h - $side, 2), ZAM_PHOTO_SIZE, ZAM_PHOTO_SIZE, $side, $side);
  $dir = zam_photo_dir(); if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) return [null, 'Photo storage is unavailable.'];
  $name = 'h' . $helperId . '-' . bin2hex(random_bytes(8)) . '.jpg';
  $ok = imagejpeg($out, $dir . '/' . $name, 85); imagedestroy($img); imagedestroy($out);
  if (!$ok) return [null, 'Could not save the photo. Please try again.'];
  zam_delete_helper_photo($oldFile);
  return [$name, null];
}
function zam_delete_helper_photo(?string $file): void { if ($file && preg_match('/^[a-z0-9-]+\.jpg$/', $file)) { $p = zam_photo_dir() . '/' . $file; if (is_file($p)) @unlink($p); } }
