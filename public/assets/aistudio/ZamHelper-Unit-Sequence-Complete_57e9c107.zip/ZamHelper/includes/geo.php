<?php
/** Maps and distances. Straight-line distance is multiplied by a road factor, then rounded to the nearest 0.5 km. */
const ZAM_ROAD_FACTOR = 1.3;
const ZAM_BBOX = ['lat_min' => -18.5, 'lat_max' => -8.0, 'lng_min' => 21.5, 'lng_max' => 34.0]; // generous box around Zambia
const ZAM_CITY_CENTRES = [
  'lusaka' => ['Lusaka', -15.4167, 28.2833], 'ndola' => ['Ndola', -12.9587, 28.6366], 'kitwe' => ['Kitwe', -12.8024, 28.2132],
  'livingstone' => ['Livingstone', -17.8419, 25.8543], 'chipata' => ['Chipata', -13.6333, 32.6500],
  'kabwe' => ['Kabwe', -14.4469, 28.4464], 'solwezi' => ['Solwezi', -12.1833, 26.4000], 'choma' => ['Choma', -16.8100, 26.9900],
];
function zam_coords_ok($lat, $lng): bool {
  if (!is_numeric($lat) || !is_numeric($lng)) return false; $lat = (float)$lat; $lng = (float)$lng;
  return $lat >= ZAM_BBOX['lat_min'] && $lat <= ZAM_BBOX['lat_max'] && $lng >= ZAM_BBOX['lng_min'] && $lng <= ZAM_BBOX['lng_max'];
}
function zam_haversine_km(float $lat1, float $lng1, float $lat2, float $lng2): float {
  $r = 6371.0; $p1 = deg2rad($lat1); $p2 = deg2rad($lat2); $dp = deg2rad($lat2 - $lat1); $dl = deg2rad($lng2 - $lng1);
  $a = sin($dp / 2) ** 2 + cos($p1) * cos($p2) * sin($dl / 2) ** 2;
  return 2 * $r * asin(min(1.0, sqrt($a)));
}
function zam_road_km(float $lat1, float $lng1, float $lat2, float $lng2): float {
  return min(500.0, round(zam_haversine_km($lat1, $lng1, $lat2, $lng2) * ZAM_ROAD_FACTOR * 2) / 2);
}
function zam_city_centre(string $city): ?array { $k = strtolower(trim($city)); return ZAM_CITY_CENTRES[$k] ?? null; }
/** Where travel starts: the helper's own base pin if they set one, otherwise the centre of the customer's city (Lusaka by default). */
function zam_origin(?PDO $pdo, int $helperId, string $city): array {
  if ($pdo && $helperId) {
    try { $q = $pdo->prepare('SELECT name,base_lat,base_lng FROM helpers WHERE id=?'); $q->execute([$helperId]); $h = $q->fetch();
      if ($h && $h['base_lat'] !== null && zam_coords_ok($h['base_lat'], $h['base_lng'])) return [(float)$h['base_lat'], (float)$h['base_lng'], $h['name'] . "'s base area"]; } catch (Throwable $e) {}
  }
  $c = zam_city_centre($city) ?? ZAM_CITY_CENTRES['lusaka'];
  return [$c[1], $c[2], $c[0] . ' city centre'];
}
function zam_osm_link(float $lat, float $lng): string { return sprintf('https://www.openstreetmap.org/?mlat=%.6f&mlon=%.6f#map=17/%.6f/%.6f', $lat, $lng, $lat, $lng); }
