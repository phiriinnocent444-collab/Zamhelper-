<?php
/** Helpers for the small JSON endpoints in /api. */
function api_json($data, int $code = 200): void {
  http_response_code($code); header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store');
  echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR); exit;
}
function api_method(string $m): void { if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== $m) { header('Allow: ' . $m); api_json(['error' => 'method_not_allowed'], 405); } }
function api_guard(string $bucket, int $limit = 120, int $window = 60): void {
  if (!throttle('api:' . $bucket, $limit, $window)) { header('Retry-After: ' . $window); api_json(['error' => 'rate_limited', 'retry_after' => $window], 429); }
}
