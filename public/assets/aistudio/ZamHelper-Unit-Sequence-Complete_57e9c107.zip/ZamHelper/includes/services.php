<?php
/**
 * Single source of truth for the service catalogue (names, blurbs, placeholder fees, icons).
 * The home page, booking form fallback and tests all read this; database.sql seeds the same rows
 * (tests/run.php fails if they ever differ). Fees are starting points, adjustable in the `services` table.
 */
const ZAM_SERVICES = [
  'cleaning'        => ['name' => 'Cleaning',                 'desc' => 'House cleaning and deep cleaning.',                'base' => 180, 'km' => 0],
  'laundry'         => ['name' => 'Laundry & ironing',        'desc' => 'Washing, drying and ironing, returned fresh.',     'base' => 120, 'km' => 0],
  'errands'         => ['name' => 'Shopping & errands',       'desc' => 'Groceries, pharmacy pickups and other errands.',   'base' => 100, 'km' => 8],
  'delivery'        => ['name' => 'Small deliveries',         'desc' => 'Parcels and packages taken where they need to go.', 'base' => 100, 'km' => 8],
  'repairs'         => ['name' => 'Minor repairs & assembly', 'desc' => 'Small fixes and furniture assembly.',              'base' => 200, 'km' => 0],
  'gardening'       => ['name' => 'Yard & garden work',       'desc' => 'Tidying, weeding and garden upkeep.',              'base' => 150, 'km' => 0],
  'tutoring'        => ['name' => 'Tutoring',                 'desc' => 'Lessons and homework help.',                       'base' => 150, 'km' => 0],
  'home_assistance' => ['name' => 'Home assistance',          'desc' => 'Everyday help around the house.',                  'base' => 150, 'km' => 0],
  'moving'          => ['name' => 'Moving & lifting',         'desc' => 'Help with moving and heavy lifting.',              'base' => 250, 'km' => 0],
  'other'           => ['name' => 'Other everyday tasks',     'desc' => 'Something else on your list? Tell us.',            'base' => 150, 'km' => 0],
];
function zam_services(): array { return ZAM_SERVICES; }
/** Shape the booking form expects: key => [name, base fee, per-km rate]. */
function zam_service_fallback(): array { $o = []; foreach (ZAM_SERVICES as $k => $s) $o[$k] = [$s['name'], $s['base'], $s['km']]; return $o; }
function zam_icon(string $key): string {
  $p = [
    'cleaning'        => '<path d="M3 11 12 3l9 8M5 10v10h9"/><path d="M18 14v6M15 17h6"/>',
    'laundry'         => '<rect x="4" y="3" width="16" height="18" rx="2"/><circle cx="12" cy="14" r="4"/><path d="M8 7h.01M11 7h.01"/>',
    'errands'         => '<path d="M3 4h2l2.4 11h10.2L20 7H6.2"/><circle cx="9" cy="19.5" r="1.5"/><circle cx="17" cy="19.5" r="1.5"/>',
    'delivery'        => '<path d="M2 6h11v10H2zM13 9h4l4 4v3h-8"/><circle cx="6.5" cy="17.5" r="1.8"/><circle cx="17.5" cy="17.5" r="1.8"/>',
    'repairs'         => '<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.6 2.6-2.4-.6-.6-2.4z"/>',
    'gardening'       => '<path d="M12 21v-9"/><path d="M12 12C12 7 8 5 4 5c0 5 3 7 8 7"/><path d="M12 14c0-4 3-6 8-6 0 5-3 7-8 7"/>',
    'tutoring'        => '<path d="m2 9 10-5 10 5-10 5z"/><path d="M6 11.5V16c3 2.4 9 2.4 12 0v-4.5"/>',
    'home_assistance' => '<path d="M3 11 12 3l9 8M5 10v10h14V10"/><path d="M12 17.5s-3-1.8-3-3.6a1.7 1.7 0 0 1 3-1 1.7 1.7 0 0 1 3 1c0 1.8-3 3.6-3 3.6z"/>',
    'moving'          => '<path d="m3 8 9-5 9 5v8l-9 5-9-5z"/><path d="m3 8 9 5 9-5M12 13v8"/>',
    'other'           => '<circle cx="5.5" cy="12" r=".6"/><circle cx="12" cy="12" r=".6"/><circle cx="18.5" cy="12" r=".6"/>',
  ];
  if (!isset($p[$key])) throw new InvalidArgumentException("No icon for service: $key");
  return '<svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $p[$key] . '</svg>';
}
