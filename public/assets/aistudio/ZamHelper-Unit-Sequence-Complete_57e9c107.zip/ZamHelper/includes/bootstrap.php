<?php
$config = require __DIR__ . '/../config.php';
$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
if (session_status() !== PHP_SESSION_ACTIVE) {
    ini_set('session.use_strict_mode', '1');
    session_set_cookie_params(['httponly'=>true, 'secure'=>$isHttps, 'samesite'=>'Lax', 'path'=>'/']);
    session_start();
}
header('X-Content-Type-Options: nosniff'); header('Referrer-Policy: strict-origin-when-cross-origin');
header('X-Frame-Options: DENY'); header('Permissions-Policy: camera=(), microphone=(), geolocation=(self)');
header('Cache-Control: no-store');
try { $pdo = new PDO('mysql:host='.$config['db_host'].';dbname='.$config['db_name'].';charset=utf8mb4',$config['db_user'],$config['db_pass'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]); }
catch (Throwable $e) { $pdo = null; }
/* The mbstring extension is common but optional; these fallbacks keep text handling working without it. */
if (!function_exists('mb_strlen')) { function mb_strlen($s, $enc = null) { return (int)preg_match_all('/./us', (string)$s); } }
if (!function_exists('mb_substr')) { function mb_substr($s, $start, $len = null, $enc = null) { $c = preg_split('//u', (string)$s, -1, PREG_SPLIT_NO_EMPTY) ?: []; return implode('', array_slice($c, $start, $len)); } }
function e($v) { return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function money($n) { return 'K'.number_format((float)$n, 2); }
function csrf_token() { if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function csrf_check() { if (!hash_equals($_SESSION['csrf'] ?? '', (string)($_POST['csrf'] ?? ''))) { http_response_code(403); exit('Invalid form token. Refresh the page and try again.'); } }
function wa_link($message, $number=null) { global $config; return 'https://wa.me/'.($number ?: $config['whatsapp']).'?text='.rawurlencode($message); }
function booking_code() { $alphabet='ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; do { $part=''; for($i=0;$i<6;$i++) $part.=$alphabet[random_int(0,strlen($alphabet)-1)]; $sum=0; for($i=0;$i<strlen($part);$i++) $sum+=strpos($alphabet,$part[$i])+1; $code='ZH-'.$part.'-'.($sum%10); global $pdo; if(!$pdo) return $code; $q=$pdo->prepare('SELECT 1 FROM bookings WHERE booking_code=?'); $q->execute([$code]); } while($q->fetchColumn()); return $code; }
function valid_phone($phone) { return (bool)preg_match('/^[+0-9 ()-]{7,20}$/', (string)$phone); }
function current_user() { global $pdo; if(empty($_SESSION['user_id']) || !$pdo) return null; static $u=false; if($u!==false)return $u; $q=$pdo->prepare('SELECT id,name,email,phone,role,is_active FROM users WHERE id=? LIMIT 1');$q->execute([$_SESSION['user_id']]);$u=$q->fetch() ?: null; if(!$u || !$u['is_active']) { unset($_SESSION['user_id']); return null; } return $u; }
function require_login($roles=[]) { $u=current_user(); if(!$u){$d=rtrim(dirname($_SERVER['SCRIPT_NAME']??'/'),'/'); $d=preg_replace('~/(admin|helper|payments)$~','',$d); header('Location: '.($d?:'').'/auth/login.php');exit;} if($roles && !in_array($u['role'],$roles,true)){http_response_code(403);exit('You do not have permission to access this page.');} return $u; }
function audit_log($actor,$action,$type,$id,$metadata=[]) { global $pdo; if(!$pdo)return; try{$q=$pdo->prepare('INSERT INTO audit_logs(actor_user_id,action,entity_type,entity_id,metadata,ip_hash) VALUES(?,?,?,?,?,?)');$q->execute([$actor,$action,$type,(string)$id,$metadata?json_encode($metadata):null,isset($_SERVER['REMOTE_ADDR'])?hash_hmac('sha256',$_SERVER['REMOTE_ADDR'],(string)(getenv('ZAM_AUDIT_SALT')?:'configure-a-real-audit-salt')):null]);}catch(Throwable $e){} }
function rate_limit($key,$limit=8,$window=900) { $now=time(); $_SESSION['rate_limits'][$key]=array_values(array_filter($_SESSION['rate_limits'][$key]??[],fn($t)=>$t>$now-$window)); if(count($_SESSION['rate_limits'][$key]) >= $limit)return false; $_SESSION['rate_limits'][$key][]=$now; return true; }

/** Rate limit by client IP (or another subject, e.g. a phone number), stored in the database so it cannot be dodged by dropping cookies.
 *  Returns false once more than $limit hits happen within $windowSeconds. Falls back to the per-session limiter if the database is unavailable. */
function client_ip(): string { return (string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'); }
function throttle(string $bucket, int $limit, int $windowSeconds, ?string $subject = null): bool {
  global $pdo; $key = hash('sha256', $bucket . '|' . ($subject ?? client_ip()));
  if ($pdo) {
    try {
      $w = max(1, $windowSeconds);
      $pdo->prepare('INSERT INTO rate_limits(bucket,hits,window_start) VALUES(?,1,NOW()) ON DUPLICATE KEY UPDATE hits=IF(window_start < NOW() - INTERVAL ? SECOND,1,hits+1), window_start=IF(window_start < NOW() - INTERVAL ? SECOND,NOW(),window_start)')->execute([$key, $w, $w]);
      $q = $pdo->prepare('SELECT hits FROM rate_limits WHERE bucket=?'); $q->execute([$key]); $hits = (int)$q->fetchColumn();
      if (random_int(1, 100) === 1) $pdo->exec('DELETE FROM rate_limits WHERE window_start < NOW() - INTERVAL 1 DAY');
      return $hits <= $limit;
    } catch (Throwable $e) { /* table missing or database error: fall through to the session limiter */ }
  }
  return rate_limit($bucket . ':' . ($subject ?? ''), $limit, $windowSeconds);
}
/** Sends a 429 page and stops. Use for form handlers that should not continue once the limit is hit. */
function throttle_or_die(string $bucket, int $limit, int $windowSeconds, ?string $subject = null): void {
  if (!throttle($bucket, $limit, $windowSeconds, $subject)) { http_response_code(429); header('Retry-After: ' . $windowSeconds); exit('Too many requests. Please wait a few minutes and try again.'); }
}
require_once __DIR__ . '/access.php';

require_once __DIR__ . '/services.php';
require_once __DIR__ . '/scheduling.php';
require_once __DIR__ . '/pricing.php';
require_once __DIR__ . '/geo.php';
require_once __DIR__ . '/notify.php';
require_once __DIR__ . '/api.php';
require_once __DIR__ . '/photos.php';
require_once __DIR__ . '/reviews.php';
require_once __DIR__ . '/helpers-data.php';
