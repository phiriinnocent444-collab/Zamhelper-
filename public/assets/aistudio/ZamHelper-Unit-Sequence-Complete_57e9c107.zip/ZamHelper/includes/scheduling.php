<?php
/**
 * Scheduling rules for bookings. All times are naive "Africa/Lusaka" local time stored in DATETIME columns
 * (created_at is written by PHP, not NOW(), so the database server's time zone never matters).
 *
 * A booking occupies a helper for [start, end):
 *   - scheduled booking: scheduled_start .. scheduled_start + duration_minutes
 *   - "as soon as possible" booking (scheduled_start IS NULL): created_at .. until it is completed or cancelled
 * Two active bookings for one helper conflict when their intervals overlap.
 */
const ZAM_TZ = 'Africa/Lusaka';
const ZAM_OPEN_HOUR = 6;       // earliest start (06:00)
const ZAM_LAST_START_HOUR = 20; // latest start (20:00)
const ZAM_MIN_NOTICE_MINUTES = 60;
const ZAM_MAX_DAYS_AHEAD = 90;
const ZAM_DEFAULT_DURATION = 120;
const ZAM_DURATIONS = [60 => '1 hour', 120 => '2 hours', 180 => '3 hours', 240 => '4 hours', 360 => '6 hours', 480 => 'Full day (8 hours)'];
const ZAM_ACTIVE_SQL = "('completed','cancelled')";

function zam_tz(): DateTimeZone { static $tz = null; return $tz ??= new DateTimeZone(ZAM_TZ); }
function zam_now(): DateTimeImmutable { return new DateTimeImmutable('now', zam_tz()); }
function zam_db_time(DateTimeInterface $d): string { return $d->format('Y-m-d H:i:s'); }

/** Parses the value of an <input type="datetime-local"> ("Y-m-d\TH:i"), or returns null when it is not valid. */
function zam_parse_slot(string $s): ?DateTimeImmutable {
  $s = trim($s);
  if (!preg_match('/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}$/', $s)) return null;
  $d = DateTimeImmutable::createFromFormat('Y-m-d H:i', str_replace('T', ' ', $s), zam_tz());
  $err = DateTimeImmutable::getLastErrors();
  if (!$d || ($err && ($err['warning_count'] || $err['error_count']))) return null;
  return $d;
}

function zam_valid_duration(int $minutes): bool { return isset(ZAM_DURATIONS[$minutes]); }

/** Returns a list of human-readable problems with a requested start time (empty list = acceptable). */
function zam_slot_errors(DateTimeImmutable $start, ?DateTimeImmutable $now = null): array {
  $now ??= zam_now(); $e = [];
  if ($start < $now->modify('+' . ZAM_MIN_NOTICE_MINUTES . ' minutes')) $e[] = 'Choose a start time at least ' . (ZAM_MIN_NOTICE_MINUTES / 60) . ' hour from now, or pick "As soon as possible".';
  if ($start > $now->modify('+' . ZAM_MAX_DAYS_AHEAD . ' days')) $e[] = 'Bookings can be made up to ' . ZAM_MAX_DAYS_AHEAD . ' days ahead.';
  $h = (int)$start->format('G');
  if ($h < ZAM_OPEN_HOUR || $h > ZAM_LAST_START_HOUR) $e[] = sprintf('Start times are between %02d:00 and %02d:59.', ZAM_OPEN_HOUR, ZAM_LAST_START_HOUR);
  return $e;
}

/** The [start, end) window a booking occupies, as DATETIME strings. $end is null for an open-ended "as soon as possible" job. */
function zam_window(?string $scheduledStart, int $duration, string $createdAt): array {
  if ($scheduledStart === null || $scheduledStart === '') return [$createdAt, null];
  $s = new DateTimeImmutable($scheduledStart, zam_tz());
  return [$scheduledStart, zam_db_time($s->modify("+{$duration} minutes"))];
}

/** Do two windows overlap? A null end means "open-ended". Strings are compared as DATETIMEs. */
function zam_windows_overlap(string $aStart, ?string $aEnd, string $bStart, ?string $bEnd): bool {
  return ($aEnd === null || $aEnd > $bStart) && ($bEnd === null || $bEnd > $aStart);
}

/**
 * Does the helper already have an active booking overlapping [$start, $end)? $end null = open-ended.
 * $excludeBookingId lets a booking be re-checked against itself (admin re-assignment).
 */
function zam_helper_conflict(PDO $pdo, int $helperId, string $start, ?string $end, int $excludeBookingId = 0): bool {
  $far = '9999-12-31 00:00:00'; $end ??= $far;
  $q = $pdo->prepare("SELECT 1 FROM bookings b WHERE b.helper_id=? AND b.id<>? AND b.status NOT IN " . ZAM_ACTIVE_SQL . "
    AND COALESCE(b.scheduled_start,b.created_at) < ?
    AND (b.scheduled_start IS NULL OR DATE_ADD(b.scheduled_start, INTERVAL b.duration_minutes MINUTE) > ?) LIMIT 1");
  $q->execute([$helperId, $excludeBookingId, $end, $start]);
  return (bool)$q->fetchColumn();
}

/** helper_id => list of [id, start, end|null] for every active booking: one query, for admin dropdowns. */
function zam_busy_map(PDO $pdo): array {
  $m = [];
  foreach ($pdo->query("SELECT id,helper_id,scheduled_start,duration_minutes,created_at FROM bookings WHERE helper_id IS NOT NULL AND status NOT IN " . ZAM_ACTIVE_SQL) as $r) {
    [$s, $e] = zam_window($r['scheduled_start'], (int)$r['duration_minutes'], $r['created_at']);
    $m[(int)$r['helper_id']][] = [(int)$r['id'], $s, $e];
  }
  return $m;
}
function zam_busy_conflict(array $busyMap, int $helperId, string $start, ?string $end, int $excludeBookingId = 0): bool {
  foreach ($busyMap[$helperId] ?? [] as [$id, $s, $e]) if ($id !== $excludeBookingId && zam_windows_overlap($start, $end, $s, $e)) return true;
  return false;
}

function zam_when_label(?string $scheduledStart, int $duration): string {
  if (!$scheduledStart) return 'As soon as possible';
  $d = new DateTimeImmutable($scheduledStart, zam_tz());
  return $d->format('D j M Y, H:i') . ' (' . (ZAM_DURATIONS[$duration] ?? ($duration . ' min')) . ')';
}
