<?php
/** Public helper listing used by helpers.php (server-rendered) and api/helpers.php (JSON), so they can never disagree. */
const ZAM_HELPERS_PER_PAGE = 6;
function zam_list_helpers(?PDO $pdo, string $q = '', string $service = '', string $sort = 'rating', int $page = 1, int $per = ZAM_HELPERS_PER_PAGE): array {
  $out = ['total' => 0, 'all_count' => 0, 'page' => 1, 'pages' => 1, 'items' => []];
  if (!$pdo) return $out;
  $now = zam_now(); $s = zam_db_time($now); $e = zam_db_time($now->modify('+1 minute'));
  try {
    $rows = $pdo->prepare("SELECT h.id,h.name,h.city,h.rating,h.review_count,h.photo_path,h.is_verified,
        GROUP_CONCAT(DISTINCT s.name ORDER BY s.name SEPARATOR ', ') AS service_names, GROUP_CONCAT(DISTINCT s.service_key) AS service_keys,
        EXISTS(SELECT 1 FROM bookings b WHERE b.helper_id=h.id AND b.status NOT IN " . ZAM_ACTIVE_SQL . "
               AND COALESCE(b.scheduled_start,b.created_at) < ? AND (b.scheduled_start IS NULL OR DATE_ADD(b.scheduled_start, INTERVAL b.duration_minutes MINUTE) > ?)) AS busy_now
      FROM helpers h LEFT JOIN helper_services hs ON hs.helper_id=h.id LEFT JOIN services s ON s.id=hs.service_id
      WHERE h.is_active=1 AND h.is_verified=1 AND h.verification_status='verified' AND h.is_available=1 GROUP BY h.id");
    $rows->execute([$e, $s]); $all = $rows->fetchAll();
  } catch (Throwable $ex) { return $out; }
  $out['all_count'] = count($all);
  $q = trim($q);
  $all = array_values(array_filter($all, function ($h) use ($q, $service) {
    if ($service !== '' && !in_array($service, explode(',', (string)$h['service_keys']), true)) return false;
    return $q === '' || stripos($h['name'] . ' ' . $h['city'] . ' ' . ($h['service_names'] ?? ''), $q) !== false;
  }));
  usort($all, fn($a, $b) => $sort === 'name' ? strcasecmp($a['name'], $b['name']) : ($sort === 'city' ? strcasecmp($a['city'], $b['city'])
      : ((float)$b['rating'] <=> (float)$a['rating'] ?: (int)$b['review_count'] <=> (int)$a['review_count'])));
  $out['total'] = count($all); $out['pages'] = max(1, (int)ceil($out['total'] / $per)); $out['page'] = min(max(1, $page), $out['pages']);
  $out['items'] = array_slice($all, ($out['page'] - 1) * $per, $per);
  return $out;
}
