<?php
/**
 * Single source of truth for who may open each signed-in area.
 * Pages call access_roles('key') and the admin matrix calls role_can(), so the two can never disagree.
 * An empty roles list means "any signed-in role". The admin area is separate (password-protected, not a user role).
 */
const ZAM_ACCESS = [
  'dashboard'        => ['label' => 'My bookings',      'roles' => [],         'scope' => 'Own bookings only'],
  'helper_workspace' => ['label' => 'Helper workspace', 'roles' => ['helper'], 'scope' => 'Own helper profile only'],
  'payments'         => ['label' => 'Payment requests', 'roles' => [],         'scope' => 'Own bookings only'],
];
function access_roles(string $key): array {
  if (!isset(ZAM_ACCESS[$key])) throw new InvalidArgumentException("Unknown access key: $key");
  return ZAM_ACCESS[$key]['roles'];
}
function role_can(string $role, string $key): bool {
  $roles = access_roles($key);
  return $roles === [] || in_array($role, $roles, true);
}
