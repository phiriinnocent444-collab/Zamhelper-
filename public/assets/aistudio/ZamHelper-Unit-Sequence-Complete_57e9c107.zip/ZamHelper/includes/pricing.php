<?php
/** One place for the price rules so the booking page, the JSON API and the tests can never disagree. */
const ZAM_URGENT_MULTIPLIER = 1.25;
function zam_price(float $base, float $perKm, float $km, bool $urgent): array {
  $km = max(0.0, min(500.0, $km)); $travel = round($perKm * $km, 2);
  $total = round(($base + $travel) * ($urgent ? ZAM_URGENT_MULTIPLIER : 1), 2);
  return ['base' => round($base, 2), 'distance_km' => $km, 'travel' => $travel, 'urgent' => $urgent, 'total' => $total];
}
/** Loads the active service catalogue: key => [name, base, per_km]. Falls back to the built-in catalogue without a database. */
function zam_load_services(?PDO $pdo): array {
  $s = zam_service_fallback();
  if ($pdo) { try { foreach ($pdo->query('SELECT service_key,name,base_fee,per_km_rate FROM services WHERE is_active=1') as $r) $s[$r['service_key']] = [$r['name'], (float)$r['base_fee'], (float)$r['per_km_rate']]; } catch (Throwable $e) {} }
  return $s;
}
