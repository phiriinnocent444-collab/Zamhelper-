<?php
/** Ratings and reviews. One review per completed booking; hidden reviews do not count. */
function zam_recalc_helper_rating(PDO $pdo, int $helperId): void {
  $q = $pdo->prepare('SELECT COUNT(*),AVG(rating) FROM reviews WHERE helper_id=? AND is_hidden=0'); $q->execute([$helperId]); [$n, $avg] = $q->fetch(PDO::FETCH_NUM);
  $pdo->prepare('UPDATE helpers SET review_count=?, rating=? WHERE id=?')->execute([(int)$n, $n ? round((float)$avg, 1) : 5.0, $helperId]);
}
/** A review may be left by the booking's own customer, once, after the job is completed. @return array{0:?array,1:?string} [booking row, reason it is not allowed] */
function zam_reviewable_booking(PDO $pdo, int $bookingId, int $userId): array {
  $q = $pdo->prepare('SELECT b.id,b.booking_code,b.status,b.helper_id,b.customer_user_id,b.service_key,h.name AS helper_name,(SELECT COUNT(*) FROM reviews r WHERE r.booking_id=b.id) AS reviewed
                      FROM bookings b LEFT JOIN helpers h ON h.id=b.helper_id WHERE b.id=? AND b.customer_user_id=? LIMIT 1');
  $q->execute([$bookingId, $userId]); $b = $q->fetch();
  if (!$b) return [null, 'Booking not found for your account.'];
  if ($b['status'] !== 'completed') return [$b, 'You can review a booking once it is completed.'];
  if (!$b['helper_id']) return [$b, 'This booking had no assigned helper to review.'];
  if ((int)$b['reviewed'] > 0) return [$b, 'You have already reviewed this booking. Thank you!'];
  return [$b, null];
}
function zam_stars(float $rating): string { $n = (int)round($rating); return str_repeat('★', $n) . str_repeat('☆', 5 - $n); }
function zam_first_name_initial(string $name): string { $p = preg_split('/\s+/', trim($name)); return ($p[0] ?? 'Customer') . (isset($p[1]) ? ' ' . mb_substr($p[1], 0, 1) . '.' : ''); }
