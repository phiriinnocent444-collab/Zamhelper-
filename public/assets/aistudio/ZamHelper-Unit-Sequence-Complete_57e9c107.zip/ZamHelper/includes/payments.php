<?php
/**
 * Provider-agnostic payment webhook. IMPORTANT: this does NOT collect money and is NOT connected to MTN MoMo or Airtel Money.
 * Those need merchant onboarding and credentials that only the business can obtain. This is the safe receiving end: once a
 * gateway (or a small bridge you run) is set up, it can POST a signed "payment succeeded" event and ZamHelper will mark the
 * enquiry and booking paid. Without ZAM_PAYMENT_WEBHOOK_SECRET the endpoint is disabled.
 *
 * Request:  POST /payments/webhook.php   header  X-Zam-Signature: sha256=<hex HMAC-SHA256 of the raw body, keyed with the secret>
 * Body:     {"event":"payment.succeeded","reference":"ZHPE-12","amount":250.00,"provider_ref":"TXN123","timestamp":1767225600}
 */
const ZAM_WEBHOOK_TOLERANCE = 300; // seconds
/** @return array{0:int,1:array} [HTTP status, JSON body] */
function zam_process_payment_webhook(PDO $pdo, string $rawBody, string $sigHeader, string $secret, ?int $now = null): array {
  $now ??= time();
  if ($secret === '') return [503, ['error' => 'webhook_disabled']];
  if (!preg_match('/^sha256=([0-9a-f]{64})$/i', trim($sigHeader), $m) || !hash_equals(hash_hmac('sha256', $rawBody, $secret), strtolower($m[1]))) return [401, ['error' => 'bad_signature']];
  $p = json_decode($rawBody, true);
  if (!is_array($p) || ($p['event'] ?? '') !== 'payment.succeeded') return [400, ['error' => 'unsupported_event']];
  $ts = (int)($p['timestamp'] ?? 0);
  if (abs($now - $ts) > ZAM_WEBHOOK_TOLERANCE) return [400, ['error' => 'stale_timestamp']];
  $ref = strtoupper(trim((string)($p['reference'] ?? ''))); $provider = trim((string)($p['provider_ref'] ?? '')); $amount = (float)($p['amount'] ?? 0);
  if ($provider === '' || strlen($provider) > 100 || !preg_match('/^[A-Za-z0-9._:-]+$/', $provider)) return [400, ['error' => 'bad_provider_ref']];
  if (!preg_match('/^ZHPE-(\d+)$/', $ref, $mm)) return [400, ['error' => 'bad_reference']];
  try {
    $pdo->beginTransaction();
    $q = $pdo->prepare('SELECT id,booking_id,customer_user_id,booking_code,amount,status FROM payment_enquiries WHERE id=? FOR UPDATE'); $q->execute([(int)$mm[1]]); $enq = $q->fetch();
    if (!$enq) { $pdo->rollBack(); return [404, ['error' => 'enquiry_not_found']]; }
    if ($enq['status'] === 'paid') { $pdo->rollBack(); return [200, ['status' => 'already_processed']]; }
    if ($enq['status'] === 'cancelled') { $pdo->rollBack(); return [409, ['error' => 'enquiry_cancelled']]; }
    if ($amount + 0.001 < (float)$enq['amount']) { $pdo->rollBack(); return [409, ['error' => 'amount_too_low']]; }
    $pdo->prepare("UPDATE payment_enquiries SET status='paid',verified_reference=? WHERE id=?")->execute(['webhook:' . $provider, $enq['id']]);
    $pdo->prepare("UPDATE bookings SET payment_status='paid' WHERE id=?")->execute([$enq['booking_id']]);
    $pdo->commit();
  } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); return [500, ['error' => 'server_error']]; }
  audit_log(null, 'payment_webhook_paid', 'payment_enquiry', $enq['id'], ['provider_ref' => $provider]);
  zam_notify((int)$enq['customer_user_id'], 'payment_paid', 'Payment received for booking ' . $enq['booking_code'] . '. Thank you!', 'dashboard.php', (int)$enq['booking_id']);
  return [200, ['status' => 'paid']];
}
