<?php
/**
 * Notifications. Every notification is stored in-app (the bell in the header). If the person has an email address and
 * mail is configured, an email is also attempted. WhatsApp has no official free sending API, so staff use ready-made
 * wa.me links (see zam_wa_link_for) instead of automated messages.
 */
function zam_wa_number(string $phone): string {
  $d = preg_replace('/\D+/', '', $phone);
  if (str_starts_with($d, '260')) return $d;
  if (str_starts_with($d, '0')) return '260' . substr($d, 1);
  return strlen($d) === 9 ? '260' . $d : $d;
}
function zam_mail(string $to, string $subject, string $body): bool {
  $from = getenv('ZAM_MAIL_FROM') ?: '';
  if ($from === '' || !filter_var($to, FILTER_VALIDATE_EMAIL) || !filter_var($from, FILTER_VALIDATE_EMAIL)) return false;
  $headers = "From: ZamHelper <$from>\r\nContent-Type: text/plain; charset=UTF-8\r\nX-Mailer: ZamHelper";
  try { return @mail($to, '=?UTF-8?B?' . base64_encode($subject) . '?=', $body, $headers); } catch (Throwable $e) { return false; }
}
/** Stores an in-app notification for a user and tries an email. Never throws: notifications must not break a booking. */
function zam_notify(?int $userId, string $event, string $message, ?string $link = null, ?int $bookingId = null): void {
  global $pdo; if (!$pdo || !$userId) return;
  try {
    $q = $pdo->prepare('INSERT INTO notifications(user_id,booking_id,event,message,link,created_at) VALUES(?,?,?,?,?,?)');
    $q->execute([$userId, $bookingId, substr($event, 0, 40), mb_substr($message, 0, 300), $link, zam_db_time(zam_now())]);
    $u = $pdo->prepare('SELECT email FROM users WHERE id=? AND is_active=1'); $u->execute([$userId]); $email = $u->fetchColumn();
    if ($email) zam_mail($email, 'ZamHelper: ' . mb_substr($message, 0, 80), $message . "\n\nOpen ZamHelper to see details.\nNever share a PIN, password or mobile-money OTP.");
  } catch (Throwable $e) {}
}
function zam_unread_count(int $userId): int {
  global $pdo; if (!$pdo) return 0;
  try { $q = $pdo->prepare('SELECT COUNT(*) FROM notifications WHERE user_id=? AND read_at IS NULL'); $q->execute([$userId]); return (int)$q->fetchColumn(); } catch (Throwable $e) { return 0; }
}
/** Customer-facing wording for a booking status change (also used for the staff WhatsApp links). */
function zam_status_message(string $status, string $code): ?string {
  return [
    'contacted'   => "ZamHelper has contacted you about booking $code.",
    'confirmed'   => "Booking $code is confirmed.",
    'in_progress' => "Your helper has started booking $code.",
    'completed'   => "Booking $code is complete. Please rate your helper.",
    'cancelled'   => "Booking $code was cancelled.",
  ][$status] ?? null;
}
/** Tells the customer (and, for assignments, the helper) about a change to a booking. $b needs: id, booking_code, customer_user_id, helper_id. */
function zam_notify_booking(array $b, string $event, ?string $status = null): void {
  global $pdo; $code = $b['booking_code'];
  if ($event === 'status' && $status) {
    $m = zam_status_message($status, $code);
    if ($m) zam_notify($b['customer_user_id'] ? (int)$b['customer_user_id'] : null, 'status_' . $status, $m, $status === 'completed' ? 'review.php?booking=' . (int)$b['id'] : 'dashboard.php', (int)$b['id']);
  } elseif ($event === 'assigned' && !empty($b['helper_id']) && $pdo) {
    zam_notify($b['customer_user_id'] ? (int)$b['customer_user_id'] : null, 'assigned', "A helper has been assigned to booking $code.", 'dashboard.php', (int)$b['id']);
    try { $q = $pdo->prepare('SELECT user_id FROM helpers WHERE id=?'); $q->execute([$b['helper_id']]); $hu = $q->fetchColumn(); } catch (Throwable $e) { $hu = null; }
    if ($hu) zam_notify((int)$hu, 'job_assigned', "New job assigned: booking $code.", 'dashboard.php', (int)$b['id']);
  }
}
