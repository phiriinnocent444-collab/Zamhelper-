# Payments: what is and is not connected

**Live mobile-money collection (MTN MoMo / Airtel Money) is NOT built.** It needs a merchant account, API credentials and
sandbox approval from the provider, which only the business owner can obtain, and it cannot be tested without them.
Today, payment still works through WhatsApp: the customer asks for payment instructions, staff confirm receipt in the
official merchant channel, then mark the enquiry paid in the admin page.

## What *is* built: a safe receiving end

`payments/webhook.php` accepts a signed "payment succeeded" event and marks the enquiry and booking as paid. When a gateway
(or a small bridge service you run) is ready, it only has to send this request.

* Disabled unless `ZAM_PAYMENT_WEBHOOK_SECRET` is set (returns 503).
* `POST` only, JSON body up to 64 KB, rate limited per IP.
* Header `X-Zam-Signature: sha256=<hex>` where `<hex>` is HMAC-SHA256 of the **raw body** keyed with the secret (constant-time compare).
* Rejects events older/newer than 5 minutes (replay protection) and amounts lower than the enquiry amount.
* Idempotent: sending the same event twice returns `already_processed` and changes nothing.
* Body: `{"event":"payment.succeeded","reference":"ZHPE-12","amount":250.00,"provider_ref":"TXN123","timestamp":1767225600}`

Example (PHP) for the sender:

```php
$body = json_encode(['event'=>'payment.succeeded','reference'=>'ZHPE-12','amount'=>250.00,'provider_ref'=>'TXN123','timestamp'=>time()]);
$sig  = 'sha256=' . hash_hmac('sha256', $body, getenv('ZAM_PAYMENT_WEBHOOK_SECRET'));
// POST $body to https://your-domain/payments/webhook.php with header "X-Zam-Signature: $sig"
```

Do not point a provider's callback straight at this endpoint unless that provider can produce this exact signature format;
otherwise put a tiny bridge in between that verifies the provider's own signature first.
