# ZamHelper ER diagram

This is the current WhatsApp-first database model. `payment_enquiries` records a customer request for payment instructions; it does not represent an automatic Airtel/MTN gateway transaction. Some relationships are logical application-level references rather than declared foreign-key constraints in the SQL schema.

```mermaid
erDiagram
    users ||--o| helpers : "may have profile"
    users ||--o{ bookings : "creates"
    helpers ||--o{ bookings : "assigned to"
    services ||--o{ bookings : "selected service"
    helpers ||--o{ helper_services : "offers"
    services ||--o{ helper_services : "offered by"
    bookings ||--o{ payment_enquiries : "has enquiries"
    users ||--o{ payment_enquiries : "requests"
    helpers ||--o{ verification_documents : "submits"
    users ||--o{ verification_documents : "reviews"
    users ||--o{ audit_logs : "performs action"
    users {
        bigint id PK
        varchar name
        varchar email UK
        varchar phone UK
        varchar password_hash
        enum role
        tinyint is_active
    }
    helpers {
        int id PK
        bigint user_id FK
        varchar name
        varchar phone
        varchar city
        text skills
        decimal rating
        enum verification_status
        tinyint is_available
    }
    services {
        int id PK
        varchar service_key UK
        varchar name
        decimal base_fee
        decimal per_km_rate
        tinyint is_active
    }
    helper_services {
        int helper_id PK,FK
        int service_id PK,FK
    }
    bookings {
        bigint id PK
        varchar booking_code UK
        bigint customer_user_id FK
        int helper_id FK
        varchar service_key FK
        decimal distance_km
        tinyint is_urgent
        decimal estimated_fee
        enum status
        enum payment_status
    }
    payment_enquiries {
        bigint id PK
        bigint booking_id FK
        bigint customer_user_id FK
        varchar booking_code
        decimal amount
        varchar payer_phone
        enum status
        varchar verified_reference
    }
    verification_documents {
        bigint id PK
        int helper_id FK
        enum document_type
        varchar private_path
        enum status
        bigint reviewed_by FK
    }
    helper_applications {
        bigint id PK
        varchar name
        varchar phone
        varchar city
        enum status
    }
    audit_logs {
        bigint id PK
        bigint actor_user_id FK
        varchar action
        varchar entity_type
        varchar entity_id
    }
```
