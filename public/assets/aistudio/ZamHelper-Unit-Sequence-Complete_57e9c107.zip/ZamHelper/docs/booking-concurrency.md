# ZamHelper booking concurrency protection

## What changed

- A selected-helper booking is saved inside a MySQL transaction.
- The helper row is locked with `SELECT ... FOR UPDATE` before checking for active assigned jobs.
- The active-job check and booking insert happen before the transaction commits.
- The admin assignment workflow also locks rows and rejects assignments to helpers who already have active jobs.
- The helper directory and admin dropdown avoid offering busy helpers.
- A job is considered active until its status is `completed` or `cancelled`.

## Why this is safer than the JavaScript demo

A JavaScript `channelBusy` variable belongs to one browser page and cannot coordinate multiple customers. Randomly generating a 30% collision does not protect real data. MySQL row locks serialize competing requests across sessions and browsers.

## Current limitation

The current form does not collect a scheduled date/time. Therefore the implementation limits a helper to one active assigned booking at a time, rather than checking for overlapping calendar slots. Unassigned requests can still be recorded and later assigned by an administrator.

## Manual test

1. Ensure two verified helpers or one verified helper with a matching service exists.
2. Create a booking for a helper, leaving the booking in `pending` or `confirmed`.
3. Submit a second booking request for the same helper. It should be rejected with an availability message.
4. Mark the first booking `completed` or `cancelled` in the admin dashboard.
5. The helper should appear available for assignment again.
6. Repeat using two browser sessions to test concurrent requests.

Use a test database first. For a future calendar-based system, add requested start/end times and a database-backed reservation/slot strategy.
