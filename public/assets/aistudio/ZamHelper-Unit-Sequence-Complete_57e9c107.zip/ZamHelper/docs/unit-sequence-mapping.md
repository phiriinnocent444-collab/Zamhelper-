# ZamHelper unit-sequence implementation map

| Unit / concept | How it appears in ZamHelper | Main files | Suggested verification |
|---|---|---|---|
| Requirements and scope | Customer/helper/admin roles, service booking, acceptance criteria | `README.md`, `docs/` | Confirm each requirement has a test |
| UI/UX and responsive design | Green/lime branding, accessible controls, mobile layouts, display settings | `assets/style.css`, `assets/ui-settings.js`, `includes/header.php` | Test narrow and wide viewports |
| Client-server architecture | Browser -> Apache/PHP -> PDO -> MySQL | `docs/architecture-diagram.mmd`, `includes/bootstrap.php` | Stop database and confirm safe error handling |
| HTML forms and validation | Booking, registration, login, helper application | `book.php`, `auth/`, `helper-apply.php` | Try missing and malformed values |
| CSS and JavaScript | Responsive layout and client-side settings; JS is not trusted for security | `assets/style.css`, `assets/ui-settings.js` | Test keyboard use and JS-disabled security |
| PHP backend and reusable includes | Shared header/footer, bootstrap, access rules and service catalogue | `includes/`, page handlers | PHP syntax lint |
| Relational database / ERD | Users, helpers, services, bookings, payment enquiries, verification documents, audit logs | `database.sql`, `docs/er-diagram.*` | Import fresh schema and inspect relationships |
| Authentication and sessions | Password hashing, session rotation, role checks, CSRF | `auth/`, `includes/access.php`, `includes/bootstrap.php` | Try unauthorized page access and CSRF-free POST |
| Pricing and business rules | Base fee + distance rate; urgent multiplier 1.25 | `book.php`, `includes/services.php` | Compare normal and urgent estimates |
| Booking protection | Transaction and row lock reject conflicting active helper assignments | `book.php`, `admin/index.php`, `docs/booking-concurrency.md` | Attempt simultaneous assignment |
| WhatsApp payment enquiry | Saved enquiry and pre-filled message to +260 772 300 053 | `payments/request.php`, `admin/index.php` | Check booking ownership, amount, reference and WhatsApp destination |
| Testing and quality | Automated checks, service catalogue consistency and contrast checks | `tests/run.php` | Run only against a development DB; script drops `zamhelper_test` |
| Deployment and maintenance | XAMPP/WSL/Termux notes, secrets, HTTPS, backup and update cautions | `README.md`, `.env.example` | Fresh-install rehearsal before public release |

## Important distinctions

- Distance is customer-entered for an estimate and is not GPS-verified. Confirm final price manually.
- WhatsApp links do not prove a message was sent. Payment must be confirmed through the official merchant channel.
- The app is a development starter, not production-certified.
