<?php
require __DIR__ . '/includes/bootstrap.php';
$u = require_login(); $pageTitle = 'Rate your helper'; $errors = []; $done = false; $b = null; $reason = 'Booking not found for your account.';
$bid = (int)(filter_var($_GET['booking'] ?? null, FILTER_VALIDATE_INT) ?: filter_var($_POST['booking_id'] ?? null, FILTER_VALIDATE_INT) ?: 0);
if ($pdo && $bid) { [$b, $reason] = zam_reviewable_booking($pdo, $bid, (int)$u['id']); }
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $b && !$reason) {
  throttle_or_die('review', 10, 3600); csrf_check();
  $rating = (int)($_POST['rating'] ?? 0); $comment = trim((string)($_POST['comment'] ?? ''));
  if ($rating < 1 || $rating > 5) $errors[] = 'Choose a rating from 1 to 5 stars.';
  if (mb_strlen($comment) > 600) $errors[] = 'Keep your comment under 600 characters.';
  if (!$errors) {
    try {
      $pdo->beginTransaction();
      $pdo->prepare('INSERT INTO reviews(booking_id,helper_id,customer_user_id,rating,comment,created_at) VALUES(?,?,?,?,?,?)')->execute([$b['id'], $b['helper_id'], $u['id'], $rating, $comment, zam_db_time(zam_now())]);
      zam_recalc_helper_rating($pdo, (int)$b['helper_id']); $pdo->commit(); $done = true;
      audit_log((int)$u['id'], 'review_created', 'booking', $b['id'], ['rating' => $rating]);
      $hu = $pdo->prepare('SELECT user_id FROM helpers WHERE id=?'); $hu->execute([$b['helper_id']]); $hid = $hu->fetchColumn();
      if ($hid) zam_notify((int)$hid, 'review_received', 'You received a ' . $rating . '-star review for booking ' . $b['booking_code'] . '.', 'dashboard.php', (int)$b['id']);
    } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); $errors[] = 'Could not save your review. You may have already reviewed this booking.'; }
  }
}
require __DIR__ . '/includes/header.php'; ?>
<section class="page-hero"><div class="eyebrow">HOW DID IT GO?</div><h1>Rate your <span class="lime">helper.</span></h1></section>
<section class="section apply-section"><div class="apply-card">
<?php if ($done): ?><div class="notice"><b>Thank you!</b><p>Your review helps other customers choose with confidence.</p></div><a class="btn btn-primary" href="dashboard.php">Back to my bookings</a>
<?php elseif ($reason): ?><div class="notice"><p><?= e($reason) ?></p></div><a class="btn btn-primary" href="dashboard.php">Back to my bookings</a>
<?php else: ?><p>Booking <b><?= e($b['booking_code']) ?></b> · <?= e($b['helper_name']) ?></p>
<?php if ($errors): ?><div class="form-errors"><ul><?php foreach ($errors as $x): ?><li><?= e($x) ?></li><?php endforeach ?></ul></div><?php endif ?>
<form method="post" class="booking-form"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="booking_id" value="<?= (int)$b['id'] ?>">
<fieldset class="star-input"><legend>Your rating *</legend><?php for ($i = 5; $i >= 1; $i--): ?><input type="radio" id="st<?= $i ?>" name="rating" value="<?= $i ?>" required <?= (int)($_POST['rating'] ?? 0) === $i ? 'checked' : '' ?>><label for="st<?= $i ?>" title="<?= $i ?> star<?= $i > 1 ? 's' : '' ?>"><span class="sr-only"><?= $i ?> star<?= $i > 1 ? 's' : '' ?></span>★</label><?php endfor ?></fieldset>
<label>Comment (optional)<textarea name="comment" rows="4" maxlength="600" placeholder="Was the helper on time, polite and careful?"><?= e($_POST['comment'] ?? '') ?></textarea></label>
<button class="btn btn-primary btn-full">Submit review</button><p class="form-legal">Your first name and last initial are shown with your review. Do not include phone numbers or addresses.</p></form><?php endif ?>
</div></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
